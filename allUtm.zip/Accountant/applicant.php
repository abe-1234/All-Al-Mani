<?php
include("session_accountant.php");
?>
<!DOCTYPE html>
<html>
<head>
<title>Accountant Portal</title>

<?php include("head.php");?>

<script>
$(document).on('click', '.btn-pay', function(){
	  var id = $(this).attr("id");
	 
	 // alert(id);
		$.ajax({
			method:"POST",
			url:"activate.php",
			data:"id="+id,
			success:function(data)
			{
				alert(data);
				if(data == "Applicants have been successfully activated"){
					location.reload(); 
				}
				
				}
			
		});
		
	});
</script>
</head>
	
<body>


<!-- header -->
	<?php include("menu.php");?>
	</br></br>
<!-- //header -->

<!-- events -->
	<div class="events">
		<div class="container">
			<h3><span>Application</span></h3>
			<div class="events-grids">
			<div class="row">
			 <div class="table-responsive">
					   <table id="applicant"  class="table table-bordered table-hover table-striped table-inverse">
						<thead class="bg-info">
							<tr >
								<td>Applicant ID</td>
								<td>Surname</td>
								<td>Othernames</td>
								<td>Nationality</td>
							    <td>NIC</td>
								<td>Gender</td>
								<td>Application Date</td>
								<td>Payment</td>
							</tr>
							<thead>
							<tbody >
							<?php
							$query = "SELECT * FROM tblapplicant WHERE AppStatus = 'Pending'";
							$result = mysqli_query($mysqli,$query);
							$num_results = mysqli_num_rows($result);
							if($num_results > 0)
							{
								for($i=0; $i<$num_results; $i++) 
								{
								 $row = mysqli_fetch_assoc($result);
								  echo "<tr><td>".$row["Applicant_ID"]."</td><td>".$row["Surname"]."</td><td>".$row["Othernames"]."</td><td>".$row["Nationality"]."</td><td>".$row["NIC"]."</td><td>".$row["Gender"]."</td><td>".$row["ApplicationDate"]."</td><td><button name='remove' class='btn btn-success btn-pay'  id='".$row["Applicant_ID"]."'>Pay</button></td></tr>";
								}
							
							}
							
							?>
						</tbody>
					   </table>
			       </div>

					
				<div class="clearfix"> </div>
			</div>
		</div>
	</div>
 </div>
<!-- //events -->
<!-- footer -->
	<?php include("footer.php");?>

<!-- //footer -->
<!-- Main JS  -->
<!-- for bootstrap working -->
	<script src="js/bootstrap.js"></script>
<!-- //for bootstrap working -->
<!-- //here ends scrolling icon -->
</body>

</html>

<?php
include("db.php");
$id = mysqli_real_escape_string($mysqli,$_GET["id"]);


	$query = "UPDATE tblapplicant SET AppStatus = 'Active',ApplicationFee = 'Paid' WHERE Applicant_ID = '$id'";
	$result = mysqli_query($mysqli,$query);
	if($result)
	{
		echo "Applicants have been successfully activated";
	}
	else 
	{
		echo("Error description: " . mysqli_error($mysqli));
		
	}


?>
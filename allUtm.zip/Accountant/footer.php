<div class="footer">
		<div class="container">
			<h2>Quick Links</h2>
			<div class="footer-grids">
				
				<div class="col-md-2 footer-grid">
					<ul>
						<li><a href="#">Semester Calender</a></li>
						<li><a href="#">Semester Timetable</a></li>
						<li><a href="#">Exam Timetable</a></li>
						
						
						
					</ul>
				</div>
				
				
				<div class="clearfix"> </div>
			</div>
			<div class="footer-copy">
				<p>© 2016 Website. All rights reserved | Design by <a href="#">University of Technology Mauritius</a></p>
			</div>
		</div>
	</div>
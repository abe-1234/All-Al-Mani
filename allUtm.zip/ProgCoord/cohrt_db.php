<?php
include_once("db.php");

if((!isset($_POST['prog'])) & (mysqli_real_escape_string($mysqli,$_POST['chrt1']) == null))
{
	echo "*Programme and Cohort are required!!";
	exit();
}
elseif(mysqli_real_escape_string($mysqli,$_POST['chrt1']) == null)
{
	echo "Enter a Cohort!!";
	exit();
}
elseif(!isset($_POST['prog'])) {
	echo "Enter a Programme!!";
	exit();
}
else {
	$cohort = mysqli_real_escape_string($mysqli,$_POST['chrt1']);
	$cohort1 = strtoupper($cohort);
	$prog = $_POST['prog'];
	
	$query="SELECT * FROM tblcohort WHERE Cohort_ID = '$cohort1'";
	$result=mysqli_query($mysqli,$query) or die('error');
	if (mysqli_num_rows($result))
	{
	     echo('This cohort is already existed');
		 exit();
	}
	else{
		$query="INSERT INTO tblcohort (Cohort_ID,C_level,C_semester,C_status,C_flagged,Date_updated,ProgrammeId) VALUES ('$cohort1','1','1','active','Open',now(),'$prog')";
		
		if (!mysqli_query($mysqli,$query))
		{
			echo("Error description: " . mysqli_error($mysqli));

		}
		else
		{
			
		echo "New Cohort has inserted and the page will be refreshed in a few seconds";
			
		}
	}
}
	
	
?>
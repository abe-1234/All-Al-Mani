<?php
include("session_progCoord.php");
?>
<!DOCTYPE html>
<html>
<head>
<title>Programme Coordinator Portal</title>

<?php include("head.php");?>

</head>
	
<body>


<!-- header -->
	<?php include("menu.php");?>
	</br></br>
<!-- //header -->

<!-- events -->
	<div class="events">
		<div class="container">
			<h3><span>Registration of Students</span></h3>
			<div class="events-grids">
			<div class="row">
			 
            <div class="table-responsive">
					   <table id="tblApp"  class="table table-bordered table-hover table-striped table-inverse">
						<thead class="bg-info">
							<tr >
								<td>Surname</td>
								<td>Name</td>
								<td>Nationality</td>
								<td>NIC</td>
								<td>Application Fee</td>
								<td>Register/view more</td>
								
								
								
							</tr>
							<thead>
							<tbody >
							<?php
							$query = "SELECT * FROM tblapplicant WHERE AppStatus = 'Active' AND Cohort_ID IS NULL";
							$result = mysqli_query($mysqli,$query);
							$num_results = mysqli_num_rows($result);
							
							for($i=0; $i<$num_results; $i++)
								{
                                 $row = mysqli_fetch_assoc($result);
							
								  echo "<tr><td>".$row["Surname"]."</td><td>".$row["Othernames"]."</td><td>".$row["Nationality"]."</td><td>".$row["NIC"]."</td><td>".$row["ApplicationFee"]."</td><td><a href = Applicant_info.php?id='".$row["Applicant_ID"]."'>Click</a></td></tr>";			
								}
							
							
							
							?>
						</tbody>
					   </table>
			       </div>
			
				<div class="clearfix"> </div>
			</div>
		</div>
	</div>
 </div>
<!-- //events -->
<!-- footer -->
	<?php include("footer.php");?>

<!-- //footer -->
<!-- Main JS  -->

<!-- //here ends scrolling icon -->
</body>

</html>
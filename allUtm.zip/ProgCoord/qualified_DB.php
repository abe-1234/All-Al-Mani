<?php
include("db.php");


$id = $_POST["appid"];

if((!isset($_POST["progApp"]))& (!isset($_POST["chrt"])) & (!isset($_POST["S_status"])))
{
		echo "*All are required!!";
		exit();
}
elseif((!isset($_POST["progApp"]))& (!isset($_POST["chrt"])))
{
	echo "*Programme and Cohort are required!!";
		exit();
}
elseif((!isset($_POST["S_status"]))& (!isset($_POST["chrt"])))
{
	echo "*Status and Cohort are required!!";
		exit();
}
elseif(!isset($_POST["S_status"]))
{
		echo "*Status is required!!";
		exit();
}
elseif(!isset($_POST["chrt"]))
{
		echo "*Cohort is required!!";
		exit();
}
elseif(!isset($_POST["progApp"]))
{
		echo "*Programme is required!!";
		exit();
}
else{
	
	$prog = $_POST["progApp"];
	$cohort = $_POST["chrt"];
	$status = $_POST["S_status"];

	 $query = "SELECT * FROM tblapplicant WHERE AppStatus = 'Active' AND Applicant_ID = '$id' AND Cohort_ID IS NULL";
	 $result = mysqli_query($mysqli,$query);
	 $num_results = mysqli_num_rows($result);
	 if ($num_results > 0)
	 {
	 
 
		$query = "UPDATE tblapplicant SET ScreeningDate = now(),Cohort_ID = '$cohort',ProgAcpt = '$prog',SStatus = '$status'  WHERE Applicant_ID = '$id'";
		$result = mysqli_query($mysqli,$query);
		if($result)
		{
			echo "Saved!!";
		}
		else 
		{
			echo("Error description: " . mysqli_error($mysqli));
			
		}
   }
 
	 else 
	 {
		 echo "This student has already been Screened";
	 }
 }
?>
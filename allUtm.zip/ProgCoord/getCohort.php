<html>
<?php
include "db.php";
$prog = $_POST["prog"];

$query = "SELECT * FROM tblcohort WHERE ProgrammeID='$prog' AND C_flagged = 'Open'";

 
$result=$mysqli->query($query);

?>
 <option disabled selected>Select Cohort</option> 
<?php
	while ($rs=$result->fetch_assoc()) {

?>
			<option value="<?php echo $rs["Cohort_ID"]; ?>"><?php echo $rs["Cohort_ID"]; ?></option>



<?php
	}
?>
</html> 

<?php
include("session_progCoord.php");
$id = htmlEntities($_GET['id']);
if(!$id)
{
  $_SESSION['login'] == false;
  session_destroy();
  echo "<script>window.location.href = '../UTM/login.php'</script>";
  exit();
}
// echo $id;
// exit();
?>

<!DOCTYPE html>
<html>
<head>

<style>
    a{
      font-size: 17px;
    }
  </style>
   
   <script type="text/javascript" src="js/ajax.js"></script>
  
  


  <!--<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">-->
  <!--<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>-->
  <!--<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>-->
   
   <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" media="all" />



<title>Programme Coordinator Portal</title>
<?php include("head.php");?>
<script type="text/javascript" src="js/jquery-2.1.4.min.js"></script>
<script type="text/javascript" src="js/jquery-1.11.1.js"></script>
<script>
function qualifiedStud()
{
	var data1 = $('#studfrm').serialize();
                    $.ajax({
                        type: "POST",
                        url: "qualified_DB.php",
                        data: data1,
                        success: function(msg) {
                            alert(msg);
							if(msg == "Saved!!"){
								window.history.back();
							}
							$('#studfrm')[0].reset();
                            
							 
                           
                        }
                    });
}
function addCohort(){
                    $.ajax({
						url:"cohrt_db.php",
						method:"POST",
						data:$('#add_chrt').serialize(),
						success:function(data)
						{
							alert(data);
							if(data == "New Cohort has inserted and the page will be refreshed in a few seconds")
							{
								location.reload();
								
							}
							else{
								$('#add_chrt')[0].reset();
							}
							
							
						}
						
					});
}
function getCohort(val)
  {
	  

   $.ajax({
    method:"POST",
    url: "getCohort.php", 
    data: 'prog='+val,
    success: function(data){
      $("#chrt").html(data);
  
    }
   });

  }


</script>
<script type="text/javascript">


	jQuery(document).ready(function($) {
		$(".scroll").click(function(event){		
			event.preventDefault();
			$('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
			
			
		});
		
		$("#edit_cohrt").hide(); 
		$("#addchrt").click(function(){
			$("#edit_cohrt").show(); 
			 
		});
		 $("#cancel1").click(function(){
			$("#edit_cohrt").hide(); 
			
			window.location.href="#chrt";
			$('#add_chrt')[0].reset();
		});
		
	});
</script>


<script type-"text/javascript">
      $(document).ready(function(){
        $('#next1').click(function() {
          //if ($("#lectfrm").valid()){
              activaTab('box1');
          //}
        });
        $('#next2').click(function() {
          //if ($("#lectfrm").valid()){
              activaTab('box2');
          //}
        });
        $('#next3').click(function() {
          //if ($("#lectfrm").valid()){
              activaTab('box3');
          //}
        });
        $('#next4').click(function() {
          //if ($("#lectfrm").valid()){
              activaTab('box4');
          //}
        });
        $('#next5').click(function() {
          //if ($("#lectfrm").valid()){
              activaTab('box5');
          //}
        });
        $('#next6').click(function() {
          //if ($("#lectfrm").valid()){
              activaTab('box6');
          //}
        });


        
      });

      function activaTab(tab){
        $('.nav-tabs a[href="#' + tab + '"]').tab('show');
      };
    </script>
</head>
	
<body>


<!-- header -->
	<?php include("menu.php");?>
	</br></br>
<!-- //header -->

<!-- events -->
	<div class="events">
		<div class="container">
			<h3><span>Registration of Students</span></h3>
			<div class="events-grids">
				<div class="row">
				<!--- Student registration-->
				 <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" onsubmit="return false;" method="POST" id="studfrm" >
				    <div class="form-group row">
						 <label for="progApp" class="col-sm-2 col-form-label" >Programme Applied</label>
						   <div class="form-group row">
							  <div class="col-sm-9"> 
								<select name="progApp" onchange="getCohort(this.value);" class="form-control" required   id="progApp" >
								 <option disabled selected >Select Programme</option>
								 
								 <?php
								 
									$res=$mysqli->query("SELECT ap.Applicant_ID, ap.ProgrammeID,pr.ProgrammeTitle FROM tblprogrammeapplicant AS ap, tblprogramme AS pr WHERE ap.ProgrammeID = pr.ProgrammeID AND ap.Applicant_ID = $id");
									while($row=$res->fetch_array())
									{  
									?>
									<option value="<?php echo $row['ProgrammeID']; ?>"><?php echo $row['ProgrammeTitle']; ?></option>
									<?php
									}
									?>
								</select>
							  </div>
								
						      </div>	
				    </div>
					
					<div class="form-group row">
						 <label for="chrt" class="col-sm-2 col-form-label" >Cohort</label>
						   <div class="form-group row">
							  <div class="col-sm-9"> 
								<select name="chrt" class="form-control" required  id="chrt" >
								 <option disabled selected >Select Cohort</option>
								 
								</select>
							  </div>
								<a href="#"><button type="button" name="addchrt" class="btn btn-success" id="addchrt">+</button></a>
						      </div>	
				    </div>
					
						<div class="form-group row">
							  <label for="S_status" class="col-sm-2 col-form-label">Student Status</label>
							  <div class="col-sm-9"> 
							    <select name="S_status" required class=" form-control">
								<option disabled selected value="Select Status">Select Status</option>
								  <option>Qualified</option>
								  <option>Not-Qualified</option>
								 </select>
							  </div>
						</div>
						<div class="form-group row">
					 <input type="hidden" readonly="true"  name="appid" id="appid" value = <?php echo $id; ?>  class="form-control"/>
					 </div>
						</br></br>
						<div class="btn-group" style="float:right;">
						<button type="submit"  id="submit" onclick="qualifiedStud();" class="btn btn-info">Submit</button>
						<button type="reset" class="btn btn-danger">Cancel</button>
						</div> 
				 </form>
				 <!-- Add new Cohort-->
				<div id="edit_cohrt" align="center">
				  <div class="panel panel-default">
                  <div class="panel-heading">Adding new Cohort</div>
				   <div class="panel-body">
					<form name="add_chrt" id="add_chrt">
						<div class="form-group row">
						 <label for="prog" class="col-sm-2 col-form-label" >Programme</label>
						   <div class="form-group row">
							  <div class="col-sm-9"> 
								<select name="prog" class="form-control" required id="prog" >
								 <option disabled selected >Select Programme</option>
								 
								 <?php
								 
									$res=$mysqli->query("SELECT * FROM tblprogramme");
									while($row=$res->fetch_array())
									{  
									?>
									<option value="<?php echo $row['ProgrammeID']; ?>"><?php echo $row['ProgrammeTitle']; ?></option>
									<?php
									}
									?>
								</select>
							  </div>
								
						  </div>	
						</div>
						<div class="form-group row">
							  <label for="chrt1" class="col-sm-2 col-form-label" >New Cohort</label>
							  <div class="col-sm-9">
							    <input type="text" id="chrt1" name="chrt1"  required  placeholder="e.g BSE/14A/FT" class="form-control" >
							</div>
						</div>
						</br></br>
						<div class="btn-group" style="float:right;">
						<input type="button" name="submit1" id="submit1" onclick="addCohort();" class="btn btn-info"  value="Add" />
						<input type="button" name="cancel1" id="cancel1" class="btn btn-warning" value="Cancel" />
						</div> 
					</form>
					
						
					</div>
				   </div>
				</div>
				<!-- END of Add new Cohort -->
				
				</br></br>
            <ul class="nav nav-tabs">
              <li class="active"><a data-toggle="tab" href="#box">Personal Details</a></li>
              <li><a data-toggle="tab" href="#box1">Programme of Study<br/>& Educational Details</a></li>
              <li><a data-toggle="tab" href="#box2">Results & Qualifications</a></li>
              <li><a data-toggle="tab" href="#box3">Employment</a></li>
              <li><a data-toggle="tab" href="#box4">Referee</a></li>
              <li><a data-toggle="tab" href="#box5">Under 18</a></li>
              <li><a data-toggle="tab" href="#box6">Declaration of Applicant</a></li>
            </ul> 
          <br/>
          
          <div class="tab-content">
            <div id="box" class="tab-pane fade in active">
              <div class="form-group row">
                <label for="surname" class="col-sm-2 col-form-label" >Surname</label>
                  <div class="col-sm-10">
                    <input type="text" id="surname" name="surname" class="form-control" >
                  </div>
              </div>

              <div class="form-group row">
                <label for="othername" class="col-sm-2 col-form-label" >Other Name(s)</label>
                  <div class="col-sm-10">
                    <input type="text" id="othername" name="othername" class="form-control" >
                  </div>
              </div>

              <div class="form-group row">
                <label for="maidenname" class="col-sm-2 col-form-label" >Maiden Name</label>
                  <div class="col-sm-10">
                    <input type="text" id="maidenname" name="maidenname" class="form-control">
                  </div>
              </div>

              <div class="form-group row">
                <label for="dob" class="col-sm-2 col-form-label" >Date of Birth</label>
                  <div class="col-sm-10">
                    <input type='date' name='dob' id='dob' onchange="NIC()" class="form-control"><br/>
                  </div>
              </div>

              <div class="form-group row">
                <label class="col-sm-2 col-form-label">Gender</label>
                  <div class="col-sm-10">
                    <label class="form-check-inline">
                      <input class="form-check-input" type="radio" id="female" value="Female" name="gender">Female&nbsp;&nbsp;&nbsp;
                    </label>
                          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    <label class="form-check-inline">
                      <input class="form-check-input" type="radio" id="male" value="Male" checked name="gender" >Male
                    </label>
                  </div>
              </div>

              <div class="form-group row">
                <label class="col-sm-2 col-form-label">Marital Status</label>
                  <div class="col-sm-10">
                    <label class="form-check-inline">
                      <input class="form-check-input" type="radio" id="married" value="Married" name="maritalstatus">Married&nbsp;&nbsp;&nbsp;
                    </label>
                          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    <label class="form-check-inline">
                      <input class="form-check-input" type="radio" id="single" checked value="Single" name="maritalstatus">Single
                    </label>
                  </div>
              </div>

              <div class="form-group row">
                <label class="col-sm-2 col-form-label">Nationality</label>
                  <div class="col-sm-10">
                    <label class="form-check-inline">
                      <input class="form-check-input" type="radio" checked id="Mauritian" value="Mauritian"  name="nat">Mauritian&nbsp;&nbsp;&nbsp;
                    </label>
                          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    <label class="form-check-inline">
                      <input class="form-check-input" type="radio" id="other" value="Other" name="nat">Other
                      &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;If not Mauritian, specify
                      <input type="text" id="othernat">
                    </label>

                  </div>
              </div>

              <div class="form-group row">
                <label for="NatId" class="col-sm-2 col-form-label" >National ID No.</label>
                  <div class="col-sm-10">
                    <input type="text" id="NatId" name="NatId" minlength="14" maxlength="14" class="form-control">
                  </div>
              </div>

              <div class="form-group row">
                <label class="col-sm-2 col-form-label">Address for Correspondence</label>
                  <div class="col-sm-10">
                    <label class="form-check-inline">
                      City&nbsp;&nbsp;
                      <select name="lcity" onchange="getLocation(this.value);"  id="lcity">
                       <option disabled selected>Select City/Village</option>
                       <?php
                       $res=$mysqli->query("SELECT * FROM tblcity");
                       while($row=$res->fetch_array())
                       {
                        ?>
                        <option value="<?php echo $row['CityID']; ?>"><?php echo $row['CityName']; ?></option>
                        <?php
                       }
                       ?>
                      
                      </select>
                    </label>
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    <label class="form-check-inline">
                      Sublocality&nbsp;&nbsp;
                      <select name="lsublocality"  id="lsublocality">
                        <option disabled selected>Select Sublocality</option>
                      </select>
                    </label>

                  </div>
              </div>

              <div class="form-group row">
                <label class="col-sm-2 col-form-label">Country</label>
                      &nbsp;&nbsp;&nbsp;
                      <select class="form-check-input" name="country" id="country" >
                        <option value="Afghanistan">Afghanistan</option>
                        <option value="Albania">Albania</option>
                        <option value="Algeria">Algeria</option>
                        <option value="American Samoa">American Samoa</option>
                        <option value="Andorra">Andorra</option>
                        <option value="Angola">Angola</option>
                        <option value="Anguilla">Anguilla</option>
                        <option value="Antartica">Antarctica</option>
                        <option value="Antigua and Barbuda">Antigua and Barbuda</option>
                        <option value="Argentina">Argentina</option>
                        <option value="Armenia">Armenia</option>
                        <option value="Aruba">Aruba</option>
                        <option value="Australia">Australia</option>
                        <option value="Austria">Austria</option>
                        <option value="Azerbaijan">Azerbaijan</option>
                        <option value="Bahamas">Bahamas</option>
                        <option value="Bahrain">Bahrain</option>
                        <option value="Bangladesh">Bangladesh</option>
                        <option value="Barbados">Barbados</option>
                        <option value="Belarus">Belarus</option>
                        <option value="Belgium">Belgium</option>
                        <option value="Belize">Belize</option>
                        <option value="Benin">Benin</option>
                        <option value="Bermuda">Bermuda</option>
                        <option value="Bhutan">Bhutan</option>
                        <option value="Bolivia">Bolivia</option>
                        <option value="Bosnia and Herzegowina">Bosnia and Herzegowina</option>
                        <option value="Botswana">Botswana</option>
                        <option value="Bouvet Island">Bouvet Island</option>
                        <option value="Brazil">Brazil</option>
                        <option value="British Indian Ocean Territory">British Indian Ocean Territory</option>
                        <option value="Brunei Darussalam">Brunei Darussalam</option>
                        <option value="Bulgaria">Bulgaria</option>
                        <option value="Burkina Faso">Burkina Faso</option>
                        <option value="Burundi">Burundi</option>
                        <option value="Cambodia">Cambodia</option>
                        <option value="Cameroon">Cameroon</option>
                        <option value="Canada">Canada</option>
                        <option value="Cape Verde">Cape Verde</option>
                        <option value="Cayman Islands">Cayman Islands</option>
                        <option value="Central African Republic">Central African Republic</option>
                        <option value="Chad">Chad</option>
                        <option value="Chile">Chile</option>
                        <option value="China">China</option>
                        <option value="Christmas Island">Christmas Island</option>
                        <option value="Cocos Islands">Cocos (Keeling) Islands</option>
                        <option value="Colombia">Colombia</option>
                        <option value="Comoros">Comoros</option>
                        <option value="Congo">Congo</option>
                        <option value="Congo">Congo, the Democratic Republic of the</option>
                        <option value="Cook Islands">Cook Islands</option>
                        <option value="Costa Rica">Costa Rica</option>
                        <option value="Cota D'Ivoire">Cote d'Ivoire</option>
                        <option value="Croatia">Croatia (Hrvatska)</option>
                        <option value="Cuba">Cuba</option>
                        <option value="Cyprus">Cyprus</option>
                        <option value="Czech Republic">Czech Republic</option>
                        <option value="Denmark">Denmark</option>
                        <option value="Djibouti">Djibouti</option>
                        <option value="Dominica">Dominica</option>
                        <option value="Dominican Republic">Dominican Republic</option>
                        <option value="East Timor">East Timor</option>
                        <option value="Ecuador">Ecuador</option>
                        <option value="Egypt">Egypt</option>
                        <option value="El Salvador">El Salvador</option>
                        <option value="Equatorial Guinea">Equatorial Guinea</option>
                        <option value="Eritrea">Eritrea</option>
                        <option value="Estonia">Estonia</option>
                        <option value="Ethiopia">Ethiopia</option>
                        <option value="Falkland Islands">Falkland Islands (Malvinas)</option>
                        <option value="Faroe Islands">Faroe Islands</option>
                        <option value="Fiji">Fiji</option>
                        <option value="Finland">Finland</option>
                        <option value="France">France</option>
                        <option value="France Metropolitan">France, Metropolitan</option>
                        <option value="French Guiana">French Guiana</option>
                        <option value="French Polynesia">French Polynesia</option>
                        <option value="French Southern Territories">French Southern Territories</option>
                        <option value="Gabon">Gabon</option>
                        <option value="Gambia">Gambia</option>
                        <option value="Georgia">Georgia</option>
                        <option value="Germany">Germany</option>
                        <option value="Ghana">Ghana</option>
                        <option value="Gibraltar">Gibraltar</option>
                        <option value="Greece">Greece</option>
                        <option value="Greenland">Greenland</option>
                        <option value="Grenada">Grenada</option>
                        <option value="Guadeloupe">Guadeloupe</option>
                        <option value="Guam">Guam</option>
                        <option value="Guatemala">Guatemala</option>
                        <option value="Guinea">Guinea</option>
                        <option value="Guinea-Bissau">Guinea-Bissau</option>
                        <option value="Guyana">Guyana</option>
                        <option value="Haiti">Haiti</option>
                        <option value="Heard and McDonald Islands">Heard and Mc Donald Islands</option>
                        <option value="Holy See">Holy See (Vatican City State)</option>
                        <option value="Honduras">Honduras</option>
                        <option value="Hong Kong">Hong Kong</option>
                        <option value="Hungary">Hungary</option>
                        <option value="Iceland">Iceland</option>
                        <option value="India">India</option>
                        <option value="Indonesia">Indonesia</option>
                        <option value="Iran">Iran (Islamic Republic of)</option>
                        <option value="Iraq">Iraq</option>
                        <option value="Ireland">Ireland</option>
                        <option value="Israel">Israel</option>
                        <option value="Italy">Italy</option>
                        <option value="Jamaica">Jamaica</option>
                        <option value="Japan">Japan</option>
                        <option value="Jordan">Jordan</option>
                        <option value="Kazakhstan">Kazakhstan</option>
                        <option value="Kenya">Kenya</option>
                        <option value="Kiribati">Kiribati</option>
                        <option value="Democratic People's Republic of Korea">Korea, Democratic People's Republic of</option>
                        <option value="Korea">Korea, Republic of</option>
                        <option value="Kuwait">Kuwait</option>
                        <option value="Kyrgyzstan">Kyrgyzstan</option>
                        <option value="Lao">Lao People's Democratic Republic</option>
                        <option value="Latvia">Latvia</option>
                        <option value="Lebanon">Lebanon</option>
                        <option value="Lesotho">Lesotho</option>
                        <option value="Liberia">Liberia</option>
                        <option value="Libyan Arab Jamahiriya">Libyan Arab Jamahiriya</option>
                        <option value="Liechtenstein">Liechtenstein</option>
                        <option value="Lithuania">Lithuania</option>
                        <option value="Luxembourg">Luxembourg</option>
                        <option value="Macau">Macau</option>
                        <option value="Macedonia">Macedonia, The Former Yugoslav Republic of</option>
                        <option value="Madagascar">Madagascar</option>
                        <option value="Malawi">Malawi</option>
                        <option value="Malaysia">Malaysia</option>
                        <option value="Maldives">Maldives</option>
                        <option value="Mali">Mali</option>
                        <option value="Malta">Malta</option>
                        <option value="Marshall Islands">Marshall Islands</option>
                        <option value="Martinique">Martinique</option>
                        <option value="Mauritania">Mauritania</option>
                        <option value="Mauritius" selected>Mauritius</option>
                        <option value="Mayotte">Mayotte</option>
                        <option value="Mexico">Mexico</option>
                        <option value="Micronesia">Micronesia, Federated States of</option>
                        <option value="Moldova">Moldova, Republic of</option>
                        <option value="Monaco">Monaco</option>
                        <option value="Mongolia">Mongolia</option>
                        <option value="Montserrat">Montserrat</option>
                        <option value="Morocco">Morocco</option>
                        <option value="Mozambique">Mozambique</option>
                        <option value="Myanmar">Myanmar</option>
                        <option value="Namibia">Namibia</option>
                        <option value="Nauru">Nauru</option>
                        <option value="Nepal">Nepal</option>
                        <option value="Netherlands">Netherlands</option>
                        <option value="Netherlands Antilles">Netherlands Antilles</option>
                        <option value="New Caledonia">New Caledonia</option>
                        <option value="New Zealand">New Zealand</option>
                        <option value="Nicaragua">Nicaragua</option>
                        <option value="Niger">Niger</option>
                        <option value="Nigeria">Nigeria</option>
                        <option value="Niue">Niue</option>
                        <option value="Norfolk Island">Norfolk Island</option>
                        <option value="Northern Mariana Islands">Northern Mariana Islands</option>
                        <option value="Norway">Norway</option>
                        <option value="Oman">Oman</option>
                        <option value="Pakistan">Pakistan</option>
                        <option value="Palau">Palau</option>
                        <option value="Panama">Panama</option>
                        <option value="Papua New Guinea">Papua New Guinea</option>
                        <option value="Paraguay">Paraguay</option>
                        <option value="Peru">Peru</option>
                        <option value="Philippines">Philippines</option>
                        <option value="Pitcairn">Pitcairn</option>
                        <option value="Poland">Poland</option>
                        <option value="Portugal">Portugal</option>
                        <option value="Puerto Rico">Puerto Rico</option>
                        <option value="Qatar">Qatar</option>
                        <option value="Reunion">Reunion</option>
                        <option value="Romania">Romania</option>
                        <option value="Russia">Russian Federation</option>
                        <option value="Rwanda">Rwanda</option>
                        <option value="Saint Kitts and Nevis">Saint Kitts and Nevis</option> 
                        <option value="Saint LUCIA">Saint LUCIA</option>
                        <option value="Saint Vincent">Saint Vincent and the Grenadines</option>
                        <option value="Samoa">Samoa</option>
                        <option value="San Marino">San Marino</option>
                        <option value="Sao Tome and Principe">Sao Tome and Principe</option> 
                        <option value="Saudi Arabia">Saudi Arabia</option>
                        <option value="Senegal">Senegal</option>
                        <option value="Seychelles">Seychelles</option>
                        <option value="Sierra">Sierra Leone</option>
                        <option value="Singapore">Singapore</option>
                        <option value="Slovakia">Slovakia (Slovak Republic)</option>
                        <option value="Slovenia">Slovenia</option>
                        <option value="Solomon Islands">Solomon Islands</option>
                        <option value="Somalia">Somalia</option>
                        <option value="South Africa">South Africa</option>
                        <option value="South Georgia">South Georgia and the South Sandwich Islands</option>
                        <option value="Span">Spain</option>
                        <option value="SriLanka">Sri Lanka</option>
                        <option value="St. Helena">St. Helena</option>
                        <option value="St. Pierre and Miguelon">St. Pierre and Miquelon</option>
                        <option value="Sudan">Sudan</option>
                        <option value="Suriname">Suriname</option>
                        <option value="Svalbard">Svalbard and Jan Mayen Islands</option>
                        <option value="Swaziland">Swaziland</option>
                        <option value="Sweden">Sweden</option>
                        <option value="Switzerland">Switzerland</option>
                        <option value="Syria">Syrian Arab Republic</option>
                        <option value="Taiwan">Taiwan, Province of China</option>
                        <option value="Tajikistan">Tajikistan</option>
                        <option value="Tanzania">Tanzania, United Republic of</option>
                        <option value="Thailand">Thailand</option>
                        <option value="Togo">Togo</option>
                        <option value="Tokelau">Tokelau</option>
                        <option value="Tonga">Tonga</option>
                        <option value="Trinidad and Tobago">Trinidad and Tobago</option>
                        <option value="Tunisia">Tunisia</option>
                        <option value="Turkey">Turkey</option>
                        <option value="Turkmenistan">Turkmenistan</option>
                        <option value="Turks and Caicos">Turks and Caicos Islands</option>
                        <option value="Tuvalu">Tuvalu</option>
                        <option value="Uganda">Uganda</option>
                        <option value="Ukraine">Ukraine</option>
                        <option value="United Arab Emirates">United Arab Emirates</option>
                        <option value="United Kingdom">United Kingdom</option>
                        <option value="United States">United States</option>
                        <option value="United States Minor Outlying Islands">United States Minor Outlying Islands</option>
                        <option value="Uruguay">Uruguay</option>
                        <option value="Uzbekistan">Uzbekistan</option>
                        <option value="Vanuatu">Vanuatu</option>
                        <option value="Venezuela">Venezuela</option>
                        <option value="Vietnam">Viet Nam</option>
                        <option value="Virgin Islands (British)">Virgin Islands (British)</option>
                        <option value="Virgin Islands (U.S)">Virgin Islands (U.S.)</option>
                        <option value="Wallis and Futana Islands">Wallis and Futuna Islands</option>
                        <option value="Western Sahara">Western Sahara</option>
                        <option value="Yemen">Yemen</option>
                        <option value="Yugoslavia">Yugoslavia</option>
                        <option value="Zambia">Zambia</option>
                        <option value="Zimbabwe">Zimbabwe</option>
                    </select>
              </div>

              <div class="form-group row">
                <label for="homeno" class="col-sm-2 col-form-label" >Telephone No.</label>
                  <div class="col-sm-10">
                    Home<input type="text" id="homeno" name="homeno" minlength="7" maxlength="7" class="form-control" ></div>
                <label for="officeno" class="col-sm-2 col-form-label" ></label>
                  <div class="col-sm-10">
                    Office<input type="text" id="officeno" name="officeno" minlength="7" maxlength="7" class="form-control" ></div>
                <label for="mobileno" class="col-sm-2 col-form-label" ></label> 
                  <div class="col-sm-10">
                    Mobile<input type="text" id="mobileno" name="mobileno" minlength="8" maxlength="8" value="5" class="form-control" ></div>
                <label for="faxno" class="col-sm-2 col-form-label" ></label>
                  <div class="col-sm-10">
                    Fax<input type="text" id="faxno" name="faxno" minlength="8" maxlength="8" class="form-control" ></div>
              </div> 

              <div class="form-group row">
                <label for="email" class="col-sm-2 col-form-label" >Email</label>
                  <div class="col-sm-10">
                    <input type="text" id="email" name="email" class="form-control" >
                  </div>
              </div><br/>
              &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
              <!--<a data-toggle="tab" id="next1" name="next1" href="#box1">Next</a>-->
              <button id="next1" name="next1">Next</button>

              
            </div>

            <div id="box1" class="tab-pane fade">
              <div class="form-group row">
                <label for='progapplied' class="col-sm-2 col-form-label" >Programme of study applied for(In order of preference):</label>
                  <div class="col-sm-10">
                    <select name='progapplied1' id='progapplied1' >
                      <option disabled value="0" selected>Choose programme...</option>
                        <optgroup label="Undergraduate Programmes">
                          <?php
                          $qryprog=$mysqli->query("SELECT * FROM tblprogramme WHERE Level='Under'");
                          ?>
                          <?php
                            while ($rowprog =  mysqli_fetch_assoc($qryprog)) {
                              echo '<option value="'.$rowprog['ProgrammeCode'].'">'.$rowprog['ProgrammeTitle'].'</option>';
                            }
                          ?>
                        </optgroup>
                        <optgroup label="Postgraduate Programmes">
                          <?php
                          $qryprog=$mysqli->query("SELECT * FROM tblprogramme WHERE Level='Post'");
                          ?>
                          <?php
                            while ($rowprog =  mysqli_fetch_assoc($qryprog)) {
                              echo '<option value="'.$rowprog['ProgrammeCode'].'">'.$rowprog['ProgrammeTitle'].'</option>';
                            }
                          ?>
                        </optgroup>
                    </select>&nbsp;
                    <!--<input type='text' name='progapplied1' id='progapplied1'  maxlength="70" />&nbsp;-->
                    FT<input type='radio' name='progmode1' id='rad1FT'  value='fulltime' checked/>&nbsp;
                    PT<input type='radio' name='progmode1' id='rad1PT' value='parttime'/>&nbsp;&nbsp;
                    Code<input type='text' name='prog1Code' id='prog1Code'  maxlength="6" /><br/>
                  <br/>
                  
                    <select name='progapplied2' id='progapplied2'>
                      <option disabled value="0" selected>Choose programme...</option>
                        <optgroup label="Undergraduate Programmes">
                          <?php
                          $qryprog=$mysqli->query("SELECT * FROM tblprogramme WHERE Level='Under'");
                          ?>
                          <?php
                            while ($rowprog =  mysqli_fetch_assoc($qryprog)) {
                              echo '<option value="'.$rowprog['ProgrammeCode'].'">'.$rowprog['ProgrammeTitle'].'</option>';
                            }
                          ?>
                        </optgroup>
                        <optgroup label="Postgraduate Programmes">
                          <?php
                          $qryprog=$mysqli->query("SELECT * FROM tblprogramme WHERE Level='Post'");
                          ?>
                          <?php
                            while ($rowprog =  mysqli_fetch_assoc($qryprog)) {
                              echo '<option value="'.$rowprog['ProgrammeCode'].'">'.$rowprog['ProgrammeTitle'].'</option>';
                            }
                          ?>
                        </optgroup>
                    </select>&nbsp;
                    FT<input type='radio' name='progmode2' id='rad2FT'  value='fulltime' checked/>&nbsp;
                    PT<input type='radio' name='progmode2' id='rad2PT'  value='parttime'/>&nbsp;&nbsp;
                    Code<input type='text' name='prog2Code' id='prog2Code'  maxlength="6" /><br/>
                  <br/>
                  
                    <select name='progapplied3' id='progapplied3'>
                      <option disabled value="0" selected>Choose programme...</option>
                        <optgroup label="Undergraduate Programmes">
                          <?php
                          $qryprog=$mysqli->query("SELECT * FROM tblprogramme WHERE Level='Under'");
                          ?>
                          <?php
                            while ($rowprog =  mysqli_fetch_assoc($qryprog)) {
                              echo '<option value="'.$rowprog['ProgrammeCode'].'">'.$rowprog['ProgrammeTitle'].'</option>';
                            }
                          ?>
                        </optgroup>
                        <optgroup label="Postgraduate Programmes">
                          <?php
                          $qryprog=$mysqli->query("SELECT * FROM tblprogramme WHERE Level='Post'");
                          ?>
                          <?php
                            while ($rowprog =  mysqli_fetch_assoc($qryprog)) {
                              echo '<option value="'.$rowprog['ProgrammeCode'].'">'.$rowprog['ProgrammeTitle'].'</option>';
                            }
                          ?>
                        </optgroup>
                    </select>&nbsp;
                    FT<input type='radio' name='progmode3' id='rad3FT'  value='fulltime' checked/>&nbsp;
                    PT<input type='radio' name='progmode3' id='rad3PT'  value='parttime'/>&nbsp;&nbsp;
                    Code<input type='text' name='prog3Code' id='prog3Code'  maxlength="6" /><br/>
                  
                </div><br/>
              </div>

              <div class="form-group row">
                <label for='edudetails' class="col-sm-2 col-form-label" >Educational Details:<h6>(Note: Qualifications obtained <u>after</u> the closing date will <u>not</u> be considered)</h6></label>
                <div class="col-sm-10 table-responsive">
                  <table id="edudetails" align="center" class="table table-bordered" width="400">
                    <tr>
                        <td align="center" rowspan="2"><b>Institutions</b></td>
                        <td align="center" colspan="2"><b>Entered</b></td>
                        <td align="center" colspan="2"><b>Left</b></td>
                    </tr>
                    <tr>
                        <td align="center"><b>Month</b></td>
                        <td align="center"><b>Year</b></td>
                        <td align="center"><b>Month</b></td>
                        <td align="center"><b>Year</b></td>
                    </tr>

                    <tr name="institution1" id="institution1">
                        <td><input type="text"  style="width:280px;" name="inst1"/></td>
                        <td>
                          <select name="inst1_month_ent"  id="inst1_month_ent">
                            <option disabled value="0" selected>----</option>
                            <option value="January">January</option>
                            <option value="February">February</option>
                            <option value="March">March</option>
                            <option value="April">April</option>
                            <option value="May">May</option>
                            <option value="June">June</option>
                            <option value="July">July</option>
                            <option value="August">August</option>
                            <option value="September">September</option>
                            <option value="October">October</option>
                            <option value="November">November</option>`
                            <option value="December">December</option>
                          </select>
                        </td>
                        <td><input type="text"  class="edudetails" name="inst1_year_ent"/></td>
                        <td><input type="text"  class="edudetails" name="inst1_month_left"/></td>
                        <td><input type="text"  class="edudetails" name="inst1_year_left"/></td>
                    </tr>
                    <tr name="institution2" id="institution2">
                        <td><input type="text" style="width:280px;" name="inst2"/></td>
                        <td><input type="text" class="edudetails" name="inst2_month_ent"/></td>
                        <td><input type="text" class="edudetails" name="inst2_year_ent"/></td>
                        <td><input type="text" class="edudetails" name="inst2_month_left"/></td>
                        <td><input type="text" class="edudetails" name="inst2_year_left"/></td>
                    </tr>
                    <tr name="institution3" id="institution3">
                        <td><input type="text" style="width:280px;" name="inst3"/></td>
                        <td><input type="text" class="edudetails" name="inst3_month_ent"/></td>
                        <td><input type="text" class="edudetails" name="inst3_year_ent"/></td>
                        <td><input type="text" class="edudetails" name="inst3_month_left"/></td>
                        <td><input type="text" class="edudetails" name="inst3_year_left"/></td>
                    </tr>
                  </table>
                </div>
              <br/>
              </div>
              &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
              <button id="next2" name="next2">Next</button>
            </div>

            <div id="box2" class="tab-pane fade">
              <br/>

                <label for='scresults' class="col-sm-2 col-form-label">SC Results<br/><br/>List all subjects taken, including failures, in <u>exactly the same order as on Certificates.</u>Give the three best attempts for each certificate and their years and months of examiniations. Group together all subjects taken at one sitting.</label>

                  <div class="col-sm-10">
                    <table border="1" id="scresults">
                      <tr>
                          <td align="center" rowspan="2"><b>SC/GCE O-Level<br/>Results</b></td>
                          <td align="center" rowspan="2">Index No.&rarr;</td>
                          <td align="center">1st Attempt</td>
                          <td align="center">2nd Attempt</td>
                          <td align="center">3rd Attempt</td>
                      </tr>
                      <tr>
                          <td align="center"><input type="text"  name="index_scattempt1" id="index_scattempt1"/></td>
                          <td align="center"><input type="text" name="index_scattempt2" id="index_scattempt2"/></td>
                          <td align="center"><input type="text" name="index_scattempt3" id="index_scattempt3"/></td>
                      </tr>
                      <tr>
                          <td align="center" colspan="2">Date of Attempt(Month/Year)&nbsp;&nbsp;&rarr;</td>
                          <td align="center"><input type="text"  name="date_scattempt1"/></td>
                          <td align="center"><input type="text" name="date_scattempt2"/></td>
                          <td align="center"><input type="text" name="date_scattempt3"/></td>
                          
                      </tr>

                      <tr>
                          <td align="center" colspan="2"><b>Subjects</b></td>
                          <td align="center" colspan="3"><b>Grades(e.g. 1,2,3... or A,B,C...)</b></td>
                      </tr>
                      
                      <tr name="sc_subjects1" id="sc_subjects1">
                          <td colspan="2">
                              <select name="scsub1"  id="scsub1">
                               <option disabled value="0" selected>Choose subject...</option>
                               <?php
                               $qryscsub=$mysqli->query("SELECT * FROM tblscsubjects");
                               ?>
                                <?php
                                while ($row1 =  mysqli_fetch_assoc($qryscsub)) {
                                    echo '<option value="'.$row1['Subject_ID'].'">'.$row1['SubjectTitle'].'</option>';
                                }
                                ?>
                               
                              </select>
                          </td>
                          <td><input type="text" class="grades"  name="scgrade1_att1" id="scgrade1_att1"/></td>
                          <td><input type="text" class="grades" name="scgrade1_att2" id="scgrade1_att2"/></td>
                          <td><input type="text" class="grades" name="scgrade1_att3" id="scgrade1_att3"/></td>
                      </tr>
                      <tr name="sc_subjects2" id="sc_subjects2">
                          <td colspan="2">
                              <select class="subjects"  name="scsub2" id="scsub2">
                                  <option disabled value="0" selected>Choose subject...</option>
                               <?php
                               $qryscsub=$mysqli->query("SELECT * FROM tblscsubjects");
                               ?>
                                <?php
                                while ($row1 =  mysqli_fetch_assoc($qryscsub)) {
                                    echo '<option value="'.$row1['Subject_ID'].'">'.$row1['SubjectTitle'].'</option>';
                                }
                                ?>
                               
                              </select>
                          </td>
                          <td><input type="text" class="grades"  name="scgrade2_att1" id="scgrade2_att1"/></td>
                          <td><input type="text" class="grades" name="scgrade2_att2" id="scgrade2_att2"/></td>
                          <td><input type="text" class="grades" name="scgrade2_att3" id="scgrade2_att3"/></td>
                      </tr>
                      <tr name="sc_subjects3" id="sc_subjects3">
                          <td colspan="2">
                              <select class="subjects"  name="scsub3" id="scsub3">
                                  <option disabled value="0" selected>Choose subject...</option>
                               <?php
                               $qryscsub=$mysqli->query("SELECT * FROM tblscsubjects");
                               ?>
                                <?php
                                while ($row1 =  mysqli_fetch_assoc($qryscsub)) {
                                    echo '<option value="'.$row1['Subject_ID'].'">'.$row1['SubjectTitle'].'</option>';
                                }
                                ?>
                               
                              </select>
                          </td>
                          <td><input type="text" class="grades"  name="scgrade3_att1" id="scgrade3_att1"/></td>
                          <td><input type="text" class="grades" name="scgrade3_att2" id="scgrade3_att2"/></td>
                          <td><input type="text" class="grades" name="scgrade3_att3" id="scgrade3_att3"/></td>
                      </tr>
                      <tr name="sc_subjects4" id="sc_subjects4">
                          <td colspan="2">
                              <select class="subjects"  name="scsub4" id="scsub4">
                                  <option disabled value="0" selected>Choose subject...</option>
                               <?php
                               $qryscsub=$mysqli->query("SELECT * FROM tblscsubjects");
                               ?>
                                <?php
                                while ($row1 =  mysqli_fetch_assoc($qryscsub)) {
                                    echo '<option value="'.$row1['Subject_ID'].'">'.$row1['SubjectTitle'].'</option>';
                                }
                                ?>
                               
                              </select>
                          </td>
                          <td><input type="text" class="grades"  name="scgrade4_att1" id="scgrade4_att1"/></td>
                          <td><input type="text" class="grades" name="scgrade4_att2" id="scgrade4_att2"/></td>
                          <td><input type="text" class="grades" name="scgrade4_att3" id="scgrade4_att3"/></td>
                      </tr>
                      <tr name="sc_subjects5" id="sc_subjects5">
                          <td colspan="2">
                              <select class="subjects"  name="scsub5" id="scsub5">
                                  <option disabled value="0" selected>Choose subject...</option>
                               <?php
                               $qryscsub=$mysqli->query("SELECT * FROM tblscsubjects");
                               ?>
                                <?php
                                while ($row1 =  mysqli_fetch_assoc($qryscsub)) {
                                    echo '<option value="'.$row1['Subject_ID'].'">'.$row1['SubjectTitle'].'</option>';
                                }
                                ?>
                               
                              </select>
                          </td>
                          <td><input type="text" class="grades"  name="scgrade5_att1" id="scgrade5_att1"/></td>
                          <td><input type="text" class="grades" name="scgrade5_att2" id="scgrade5_att2"/></td>
                          <td><input type="text" class="grades" name="scgrade5_att3" id="scgrade5_att3"/></td>
                      </tr>
                      <tr name="sc_subjects6" id="sc_subjects6">
                          <td colspan="2">
                              <select class="subjects"  name="scsub6" id="scsub6">
                                  <option disabled value="0" selected>Choose subject...</option>
                               <?php
                               $qryscsub=$mysqli->query("SELECT * FROM tblscsubjects");
                               ?>
                                <?php
                                while ($row1 =  mysqli_fetch_assoc($qryscsub)) {
                                    echo '<option value="'.$row1['Subject_ID'].'">'.$row1['SubjectTitle'].'</option>';
                                }
                                ?>
                               
                              </select>
                          </td>
                          <td><input type="text" class="grades"  name="scgrade6_att1" id="scgrade6_att1"/></td>
                          <td><input type="text" class="grades" name="scgrade6_att2" id="scgrade6_att2"/></td>
                          <td><input type="text" class="grades" name="scgrade6_att3" id="scgrade6_att3"/></td>
                      </tr>
                      <tr name="sc_subjects7" id="sc_subjects7">
                          <td colspan="2">
                              <select class="subjects"  name="scsub7" id="scsub7">
                                  <option disabled value="0" selected>Choose subject...</option>
                               <?php
                               $qryscsub=$mysqli->query("SELECT * FROM tblscsubjects");
                               ?>
                                <?php
                                while ($row1 =  mysqli_fetch_assoc($qryscsub)) {
                                    echo '<option value="'.$row1['Subject_ID'].'">'.$row1['SubjectTitle'].'</option>';
                                }
                                ?>
                               
                              </select>
                          </td>
                          <td><input type="text" class="grades"  name="scgrade7_att1" id="scgrade7_att1"/></td>
                          <td><input type="text" class="grades" name="scgrade7_att2" id="scgrade7_att2"/></td>
                          <td><input type="text" class="grades" name="scgrade7_att3" id="scgrade7_att3"/></td>
                      </tr>
                      <tr name="sc_subjects8" id="sc_subjects8">
                          <td colspan="2">
                              <select class="subjects" name="scsub8" id="scsub8">
                                  <option disabled value="0" selected>Choose subject...</option>
                                   <?php
                                   $qryscsub=$mysqli->query("SELECT * FROM tblscsubjects");
                                   ?>
                                    <?php
                                    while ($row1 =  mysqli_fetch_assoc($qryscsub)) {
                                        echo '<option value="'.$row1['Subject_ID'].'">'.$row1['SubjectTitle'].'</option>';
                                    }
                                    ?>
                               
                              </select>
                          </td>
                          <td><input type="text" class="grades" name="scgrade8_att1" id="scgrade8_att1"/></td>
                          <td><input type="text" class="grades" name="scgrade8_att2" id="scgrade8_att2"/></td>
                          <td><input type="text" class="grades" name="scgrade8_att3" id="scgrade8_att3"/></td>
                      </tr>
                  </table><br/><br/><br/>
                  </div>

                
                <label for="hscresults" class="col-sm-2 col-form-label">HSC Results</label>
                
                <div class="col-sm-10">
                  <table border="1" id="hscresults">
                    <tr>
                        <td align="center" rowspan="2"><b>HSC/GCE A-Level<br/>Results</b></td>
                        <td align="center" rowspan="2">Index No.&rarr;</td>
                        <td align="center">1st Attempt</td>
                        <td align="center">2nd Attempt</td>
                        <td align="center">3rd Attempt</td>
                    </tr>
                    <tr>
                        <td align="center"><input type="text" name="index_hscattempt1" id="index_hscattempt1" /></td>
                        <td align="center"><input type="text" name="index_hscattempt2" id="index_hscattempt2"/></td>
                        <td align="center"><input type="text" name="index_hscattempt3" id="index_hscattempt3"/></td>
                    </tr>
                    <tr>
                        <td align="center" colspan="2">Date of Attempt(Month/Year)&nbsp;&nbsp;&rarr;</td>
                        <td align="center"><input type="text" name="date_hscattempt1"/></td>
                        <td align="center"><input type="text" name="date_hscattempt2"/></td>
                        <td align="center"><input type="text" name="date_hscattempt3"/></td>
                        
                    </tr>

                    <tr>
                        <td align="center" colspan="2"><b>Subjects Taken at Principal Level</b></td>
                        <td align="center" colspan="3"><b>Grades(e.g. A,B,C...)</b></td>
                    </tr>
                    
                    <tr name="hsc_subjects1" id="hsc_subjects1">
                        <td colspan="2">
                            <select class="subjects" name="hscsub1" id="hscsub1">
                                <option disabled value="0" selected>Choose subject...</option>
                                   <?php
                                   $qryhscsub=$mysqli->query("SELECT * FROM tblhscsubjects WHERE Type='Main'");
                                   ?>
                                    <?php
                                    while ($row_2 =  mysqli_fetch_assoc($qryhscsub)) {
                                        echo '<option value="'.$row_2['Subject_ID'].'">'.$row_2['SubjectTitle'].'</option>';
                                    }
                                    ?>
                            </select>
                        </td>
                        <td><input type="text" class="grades" name="hscgrade1_att1" id="hscgrade1_att1"/></td>
                        <td><input type="text" class="grades" name="hscgrade1_att2" id="hscgrade1_att2"/></td>
                        <td><input type="text" class="grades" name="hscgrade1_att3" id="hscgrade1_att3"/></td>
                    </tr>
                    <tr name="hsc_subjects2" id="hsc_subjects2">
                        <td colspan="2">
                            <select class="subjects" name="hscsub2" id="hscsub2">
                                <option disabled value="0" selected>Choose subject...</option>
                                   <?php
                                   $qryhscsub=$mysqli->query("SELECT * FROM tblhscsubjects WHERE Type='Main'");
                                   ?>
                                    <?php
                                    while ($row_2 =  mysqli_fetch_assoc($qryhscsub)) {
                                        echo '<option value="'.$row_2['Subject_ID'].'">'.$row_2['SubjectTitle'].'</option>';
                                    }
                                    ?>
                            </select>
                        </td>
                        <td><input type="text" class="grades" name="hscgrade2_att1" id="hscgrade2_att1"/></td>
                        <td><input type="text" class="grades" name="hscgrade2_att2" id="hscgrade2_att2"/></td>
                        <td><input type="text" class="grades" name="hscgrade2_att3" id="hscgrade2_att3"/></td>
                    </tr>
                    <tr name="hsc_subjects3" id="hsc_subjects3">
                        <td colspan="2">
                            <select class="subjects" name="hscsub3" id="hscsub3">
                                <option disabled value="0" selected>Choose subject...</option>
                                   <?php
                                   $qryhscsub=$mysqli->query("SELECT * FROM tblhscsubjects WHERE Type='Main'");
                                   ?>
                                    <?php
                                    while ($row_2 =  mysqli_fetch_assoc($qryhscsub)) {
                                        echo '<option value="'.$row_2['Subject_ID'].'">'.$row_2['SubjectTitle'].'</option>';
                                    }
                                    ?>
                            </select>
                        </td>
                        <td><input type="text" class="grades" name="hscgrade3_att1" id="hscgrade3_att1"/></td>
                        <td><input type="text" class="grades" name="hscgrade3_att2" id="hscgrade3_att2"/></td>
                        <td><input type="text" class="grades" name="hscgrade3_att3" id="hscgrade3_att3"/></td>
                    </tr>
                    <tr name="hsc_subjects4" id="hsc_subjects4">
                        <td colspan="2">
                            <select class="subjects" name="hscsub4" id="hscsub4">
                                <option disabled value="0" selected>Choose subject...</option>
                                   <?php
                                   $qryhscsub=$mysqli->query("SELECT * FROM tblhscsubjects WHERE Type='Main'");
                                   ?>
                                    <?php
                                    while ($row_2 =  mysqli_fetch_assoc($qryhscsub)) {
                                        echo '<option value="'.$row_2['Subject_ID'].'">'.$row_2['SubjectTitle'].'</option>';
                                    }
                                    ?>
                            </select>
                        </td>
                        <td><input type="text" class="grades" name="hscgrade4_att1" id="hscgrade4_att1"/></td>
                        <td><input type="text" class="grades" name="hscgrade4_att2" id="hscgrade4_att2"/></td>
                        <td><input type="text" class="grades" name="hscgrade4_att3" id="hscgrade4_att3"/></td>
                    </tr>

                    <tr>
                        <td align="center" colspan="2"><b>Subjects Taken at Subsidiary Level</b></td>
                        <td align="center" colspan="3"><b>Grades(e.g. 1,2,3... or A,B,C...)</b></td>
                    </tr>

                    <tr name="hsc_subsub1" id="hsc_subsub1">
                        <td colspan="2">
                            <select class="subjects" name="hscsubsub1" id="hscsubsub1">
                                <option disabled value="0" selected>Choose subject...</option>
                                   <?php
                                   $qryhscsub=$mysqli->query("SELECT * FROM tblhscsubjects WHERE Type='Sub'");
                                   ?>
                                    <?php
                                    while ($row_2 =  mysqli_fetch_assoc($qryhscsub)) {
                                        echo '<option value="'.$row_2['Subject_ID'].'">'.$row_2['SubjectTitle'].'</option>';
                                    }
                                    ?>
                            </select>
                        </td>
                        <td><input type="text" class="grades" name="hscsubgrade1_att1" id="hscsubgrade1_att1"/></td>
                        <td><input type="text" class="grades" name="hscsubgrade1_att2" id="hscsubgrade1_att2"/></td>
                        <td><input type="text" class="grades" name="hscsubgrade1_att3" id="hscsubgrade1_att3"/></td>
                    </tr>
                    <tr name="hsc_subsub2" id="hsc_subsub2">
                        <td colspan="2">
                            <select class="subjects" name="hscsubsub2" id="hscsubsub2">
                                <option disabled value="0" selected>Choose subject...</option>
                                   <?php
                                   $qryhscsub=$mysqli->query("SELECT * FROM tblhscsubjects WHERE Type='Sub'");
                                   ?>
                                    <?php
                                    while ($row_2 =  mysqli_fetch_assoc($qryhscsub)) {
                                        echo '<option value="'.$row_2['Subject_ID'].'">'.$row_2['SubjectTitle'].'</option>';
                                    }
                                    ?>
                            </select>
                        </td>
                        <td><input type="text" class="grades" name="hscsubgrade2_att1" id="hscsubgrade2_att1"/></td>
                        <td><input type="text" class="grades" name="hscsubgrade2_att2" id="hscsubgrade2_att2"/></td>
                        <td><input type="text" class="grades" name="hscsubgrade2_att3" id="hscsubgrade2_att3"/></td>
                    </tr>
                    <tr name="hsc_subsub3" id="hsc_subsub3">
                        <td colspan="2">
                            <select class="subjects" name="hscsubsub3" id="hscsubsub3">
                                <option disabled value="0" selected>Choose subject...</option>
                                   <?php
                                   $qryhscsub=$mysqli->query("SELECT * FROM tblhscsubjects WHERE Type='Sub'");
                                   ?>
                                    <?php
                                    while ($row_2 =  mysqli_fetch_assoc($qryhscsub)) {
                                        echo '<option value="'.$row_2['Subject_ID'].'">'.$row_2['SubjectTitle'].'</option>';
                                    }
                                    ?>
                            </select>
                        </td>
                        <td><input type="text" class="grades" name="hscsubgrade3_att1" id="hscsubgrade3_att1"/></td>
                        <td><input type="text" class="grades" name="hscsubgrade3_att2" id="hscsubgrade3_att2"/></td>
                        <td><input type="text" class="grades" name="hscsubgrade3_att3" id="hscsubgrade3_att3"/></td>
                    </tr>
                    <tr name="hsc_subsub4" id="hsc_subsub4">
                        <td colspan="2">
                            <select class="subjects" name="hscsubsub4" id="hscsubsub4">
                                <option disabled value="0" selected>Choose subject...</option>
                                   <?php
                                   $qryhscsub=$mysqli->query("SELECT * FROM tblhscsubjects WHERE Type='Sub'");
                                   ?>
                                    <?php
                                    while ($row_2 =  mysqli_fetch_assoc($qryhscsub)) {
                                        echo '<option value="'.$row_2['Subject_ID'].'">'.$row_2['SubjectTitle'].'</option>';
                                    }
                                    ?>
                            </select>
                        </td>
                        <td><input type="text" class="grades" name="hscsubgrade4_att1" id="hscsubgrade4_att1"/></td>
                        <td><input type="text" class="grades" name="hscsubgrade4_att2" id="hscsubgrade4_att2"/></td>
                        <td><input type="text" class="grades" name="hscsubgrade4_att3" id="hscsubgrade4_att3"/></td>
                    </tr>
                </table><br/><br/><br/>
                </div>

                <br/><br/><br/>
                <label for="otherqua" class="col-sm-2 col-form-label">Other Qualifications:</label><br/>
                  <div class="col-sm-10">
                    <table border="1" id="otherqua" name="otherqua">
                        <tr>
                            <td align="center" class="otherqua"><b>Courses/Programmes</b></td>
                            <td align="center" style="width:180px;"><b>Institutions</b></td>
                            <td align="center">Grade<br/>Awarded</td>
                            <td align="center">Duration<br/>(months)</td>
                            <td align="center" style="width:100px;">From</td>
                            <td align="center" style="width:100px;"">To</td>
                        </tr>
                        <tr name="otherqua1" id="otherqua1">
                            <td><input type="text" style="width:250px;" class="otherqua" name="otherqua_course1" id="otherqua_course1"></td>
                            <td><input type="text" style="width:250px;" name="other_inst1" id="other_inst1"></td>
                            <td><input type="text" style="width:70px;" name="other_grade1" id="other_grade1"></td>
                            <td><input type="text" style="width:66px;" name="other_duration1" id="other_duration1"></td>
                            <td><input type="text" style="width:100px;" name="other_from1" id="other_from1"></td>
                            <td><input type="text" style="width:100px;" name="other_to1" id="other_to1"></td>
                        </tr>
                        <tr name="otherqua2" id="otherqua2">
                            <td><input type="text" style="width:250px;" class="otherqua" name="otherqua_course2" id="otherqua_course2"></td>
                            <td><input type="text" style="width:250px;" name="other_inst2" id="other_inst2"></td>
                            <td><input type="text" style="width:70px;" name="other_grade2" id="other_grade2"></td>
                            <td><input type="text" style="width:66px;" name="other_duration2" id="other_duration2"></td>
                            <td><input type="text" style="width:100px;" name="other_from2" id="other_from2"></td>
                            <td><input type="text" style="width:100px;" name="other_to2" id="other_to2"></td>
                        </tr>
                        <tr name="otherqua3" id="otherqua3">
                            <td><input type="text" class="otherqua" style="width:250px;" name="otherqua_course3" id="otherqua_course3"></td>
                            <td><input type="text" style="width:250px;" name="other_inst3" id="other_inst3"></td>
                            <td><input type="text" style="width:70px;" name="other_grade3" id="other_grade3"></td>
                            <td><input type="text" style="width:66px;" name="other_duration3" id="other_duration3"></td>
                            <td><input type="text" style="width:100px;" name="other_from3" id="other_from3"></td>
                            <td><input type="text" style="width:100px;" name="other_to3" id="other_to3"></td>
                        </tr>
                        <tr name="otherqua4" id="otherqua4">
                            <td><input type="text" class="otherqua" style="width:250px;" name="otherqua_course4" id="otherqua_course4"></td>
                            <td><input type="text" style="width:250px;" name="other_inst4" id="other_inst"></td>
                            <td><input type="text" style="width:70px;" name="other_grade4" id="other_grade4"></td>
                            <td><input type="text" style="width:66px;" name="other_duration4" id="other_duration4"></td>
                            <td><input type="text" style="width:100px;" name="other_from4" id="other_from4"></td>
                            <td><input type="text" style="width:100px;" name="other_to4" id="other_to4"></td>
                        </tr>
                    </table>
                    <br/>
                  </div>
                  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                  <button id="next3" name="next3">Next</button>
            </div>

            <div id="box3" class="tab-pane fade">
              <div class="form-group row">
                <label for="employment" class="col-sm-2 col-form-label">This section should be filled in by those in employment<br/><h5>Give all relevant information about previous and current employment, if applicable, as follows:</h5></label> 
                
                <div class="col-sm-10">
                 <table id="employment" name="employment" border="1" style="font-size:12px;">
                    <tr>
                        <td colspan="2" align="center">From</td>
                        <td colspan="2" align="center">To</td>
                        <td rowspan="2" align="center">Name of<br/>Employers/Firms</td>
                        <td rowspan="2" align="center">Address of<br/>Employers/Firms</td>
                        <td rowspan="2" align="center">Position<br/>Held</td>
                        <td rowspan="2" align="center">Job Description</td>
                    </tr>
                    <tr>
                        <td align="center">Month</td>
                        <td align="center">Year</td>
                        <td align="center">Month</td>
                        <td align="center">Year</td>
                    </tr>
                    <tr id="emp1" name="emp1">
                        <td>
                          <select name="from_jobmonth1" id="from_jobmonth1">
                            <option disabled value="0" selected>----</option>
                            <option value="January">January</option>
                            <option value="February">February</option>
                            <option value="March">March</option>
                            <option value="April">April</option>
                            <option value="May">May</option>
                            <option value="June">June</option>
                            <option value="July">July</option>
                            <option value="August">August</option>
                            <option value="September">September</option>
                            <option value="October">October</option>
                            <option value="November">November</option>
                            <option value="December">December</option>
                          </select>
                        </td>
                        <td>
                          <select name="from_jobyear1" id="from_jobyear1">
                            <option disabled value="0" selected>----</option>
                            <option value="2000">2000</option>
                            <option value="1999">1999</option>
                            <option value="1998">1998</option>
                            <option value="1997">1997</option>
                            <option value="1996">1996</option>
                            <option value="1995">1995</option>
                            <option value="1994">1994</option>
                            <option value="1993">1993</option>
                            <option value="1992">1992</option>
                            <option value="1991">1991</option>
                            <option value="1990">1990</option>
                            <option value="1989">1989</option>
                            <option value="1988">1988</option>
                            <option value="1987">1987</option>
                            <option value="1986">1986</option>
                            <option value="1985">1985</option>
                            <option value="1984">1984</option>
                            <option value="1983">1983</option>
                            <option value="1982">1982</option>
                            <option value="1981">1981</option>
                            <option value="1980">1980</option>
                            <option value="1979">1979</option>
                            <option value="1978">1978</option>
                            <option value="1977">1977</option>
                            <option value="1976">1976</option>
                            <option value="1975">1975</option>
                            <option value="1974">1974</option>
                            <option value="1973">1973</option>
                            <option value="1972">1972</option>
                            <option value="1971">1971</option>
                            <option value="1970">1970</option>
                            <option value="1969">1969</option>
                            <option value="1968">1968</option>
                            <option value="1967">1967</option>
                            <option value="1966">1966</option>
                            <option value="1965">1965</option>
                            <option value="1964">1964</option>
                            <option value="1963">1963</option>
                            <option value="1962">1962</option>
                            <option value="1961">1961</option>
                            <option value="1960">1960</option>
                            <option value="1959">1959</option>
                            <option value="1958">1958</option>
                            <option value="1957">1957</option>
                            <option value="1956">1956</option>
                          </select>
                        </td>
                        <td>
                          <select name="to_jobmonth1" id="to_jobmonth1">
                            <option disabled value="0" selected>----</option>
                            <option value="January">January</option>
                            <option value="February">February</option>
                            <option value="March">March</option>
                            <option value="April">April</option>
                            <option value="May">May</option>
                            <option value="June">June</option>
                            <option value="July">July</option>
                            <option value="August">August</option>
                            <option value="September">September</option>
                            <option value="October">October</option>
                            <option value="November">November</option>
                            <option value="December">December</option>
                          </select>
                        </td>
                        <td>
                          <select name="to_jobyear1" id="to_jobyear1">
                            <option disabled value="0" selected>----</option>
                            <option value="2000">2000</option>
                            <option value="1999">1999</option>
                            <option value="1998">1998</option>
                            <option value="1997">1997</option>
                            <option value="1996">1996</option>
                            <option value="1995">1995</option>
                            <option value="1994">1994</option>
                            <option value="1993">1993</option>
                            <option value="1992">1992</option>
                            <option value="1991">1991</option>
                            <option value="1990">1990</option>
                            <option value="1989">1989</option>
                            <option value="1988">1988</option>
                            <option value="1987">1987</option>
                            <option value="1986">1986</option>
                            <option value="1985">1985</option>
                            <option value="1984">1984</option>
                            <option value="1983">1983</option>
                            <option value="1982">1982</option>
                            <option value="1981">1981</option>
                            <option value="1980">1980</option>
                            <option value="1979">1979</option>
                            <option value="1978">1978</option>
                            <option value="1977">1977</option>
                            <option value="1976">1976</option>
                            <option value="1975">1975</option>
                            <option value="1974">1974</option>
                            <option value="1973">1973</option>
                            <option value="1972">1972</option>
                            <option value="1971">1971</option>
                            <option value="1970">1970</option>
                            <option value="1969">1969</option>
                            <option value="1968">1968</option>
                            <option value="1967">1967</option>
                            <option value="1966">1966</option>
                            <option value="1965">1965</option>
                            <option value="1964">1964</option>
                            <option value="1963">1963</option>
                            <option value="1962">1962</option>
                            <option value="1961">1961</option>
                            <option value="1960">1960</option>
                            <option value="1959">1959</option>
                            <option value="1958">1958</option>
                            <option value="1957">1957</option>
                            <option value="1956">1956</option>
                          </select>
                        </td>
                        <td><input type="text" style="width:200px;" name="employer1" id="employer1"></td>
                        <td><input type="text" style="width:200px;" name="employeradd1" id="employeradd1"></td>
                        <td><input type="text" style="width:160px;" name="pos1" id="pos1"></td>
                        <td><input type="text" style="width:170px;" name="job1" id="job1"></td>
                    </tr>
                    <tr id="emp2" name="emp2">
                        <td>
                          <select name="from_jobmonth2" id="from_jobmonth2">
                            <option disabled value="0" selected>----</option>
                            <option value="January">January</option>
                            <option value="February">February</option>
                            <option value="March">March</option>
                            <option value="April">April</option>
                            <option value="May">May</option>
                            <option value="June">June</option>
                            <option value="July">July</option>
                            <option value="August">August</option>
                            <option value="September">September</option>
                            <option value="October">October</option>
                            <option value="November">November</option>
                            <option value="December">December</option>
                          </select>
                        </td>
                        <td>
                          <select name="from_jobyear2" id="from_jobyear2">
                            <option disabled value="0" selected>----</option>
                            <option value="2000">2000</option>
                            <option value="1999">1999</option>
                            <option value="1998">1998</option>
                            <option value="1997">1997</option>
                            <option value="1996">1996</option>
                            <option value="1995">1995</option>
                            <option value="1994">1994</option>
                            <option value="1993">1993</option>
                            <option value="1992">1992</option>
                            <option value="1991">1991</option>
                            <option value="1990">1990</option>
                            <option value="1989">1989</option>
                            <option value="1988">1988</option>
                            <option value="1987">1987</option>
                            <option value="1986">1986</option>
                            <option value="1985">1985</option>
                            <option value="1984">1984</option>
                            <option value="1983">1983</option>
                            <option value="1982">1982</option>
                            <option value="1981">1981</option>
                            <option value="1980">1980</option>
                            <option value="1979">1979</option>
                            <option value="1978">1978</option>
                            <option value="1977">1977</option>
                            <option value="1976">1976</option>
                            <option value="1975">1975</option>
                            <option value="1974">1974</option>
                            <option value="1973">1973</option>
                            <option value="1972">1972</option>
                            <option value="1971">1971</option>
                            <option value="1970">1970</option>
                            <option value="1969">1969</option>
                            <option value="1968">1968</option>
                            <option value="1967">1967</option>
                            <option value="1966">1966</option>
                            <option value="1965">1965</option>
                            <option value="1964">1964</option>
                            <option value="1963">1963</option>
                            <option value="1962">1962</option>
                            <option value="1961">1961</option>
                            <option value="1960">1960</option>
                            <option value="1959">1959</option>
                            <option value="1958">1958</option>
                            <option value="1957">1957</option>
                            <option value="1956">1956</option>
                          </select>
                        </td>
                        <td>
                          <select name="to_jobmonth2" id="to_jobmonth2">
                            <option disabled value="0" selected>----</option>
                            <option value="January">January</option>
                            <option value="February">February</option>
                            <option value="March">March</option>
                            <option value="April">April</option>
                            <option value="May">May</option>
                            <option value="June">June</option>
                            <option value="July">July</option>
                            <option value="August">August</option>
                            <option value="September">September</option>
                            <option value="October">October</option>
                            <option value="November">November</option>
                            <option value="December">December</option>
                          </select>
                        </td>
                        <td>
                          <select name="to_jobyear2" id="to_jobyear2">
                            <option disabled value="0" selected>----</option>
                            <option value="2000">2000</option>
                            <option value="1999">1999</option>
                            <option value="1998">1998</option>
                            <option value="1997">1997</option>
                            <option value="1996">1996</option>
                            <option value="1995">1995</option>
                            <option value="1994">1994</option>
                            <option value="1993">1993</option>
                            <option value="1992">1992</option>
                            <option value="1991">1991</option>
                            <option value="1990">1990</option>
                            <option value="1989">1989</option>
                            <option value="1988">1988</option>
                            <option value="1987">1987</option>
                            <option value="1986">1986</option>
                            <option value="1985">1985</option>
                            <option value="1984">1984</option>
                            <option value="1983">1983</option>
                            <option value="1982">1982</option>
                            <option value="1981">1981</option>
                            <option value="1980">1980</option>
                            <option value="1979">1979</option>
                            <option value="1978">1978</option>
                            <option value="1977">1977</option>
                            <option value="1976">1976</option>
                            <option value="1975">1975</option>
                            <option value="1974">1974</option>
                            <option value="1973">1973</option>
                            <option value="1972">1972</option>
                            <option value="1971">1971</option>
                            <option value="1970">1970</option>
                            <option value="1969">1969</option>
                            <option value="1968">1968</option>
                            <option value="1967">1967</option>
                            <option value="1966">1966</option>
                            <option value="1965">1965</option>
                            <option value="1964">1964</option>
                            <option value="1963">1963</option>
                            <option value="1962">1962</option>
                            <option value="1961">1961</option>
                            <option value="1960">1960</option>
                            <option value="1959">1959</option>
                            <option value="1958">1958</option>
                            <option value="1957">1957</option>
                            <option value="1956">1956</option>
                          </select>
                        </td>
                        <td><input type="text" style="width:200px;" name="employer2" id="employer2"></td>
                        <td><input type="text" style="width:200px;" name="employeradd2" id="employeradd2"></td>
                        <td><input type="text" style="width:160px;" name="pos2" id="pos2"></td>
                        <td><input type="text" style="width:170px;" name="job2" id="job2"></td>
                    </tr>
                    <tr id="emp3" name="emp3">
                        <td>
                          <select name="from_jobmonth3" id="from_jobmonth3">
                            <option disabled value="0" selected>----</option>
                            <option value="January">January</option>
                            <option value="February">February</option>
                            <option value="March">March</option>
                            <option value="April">April</option>
                            <option value="May">May</option>
                            <option value="June">June</option>
                            <option value="July">July</option>
                            <option value="August">August</option>
                            <option value="September">September</option>
                            <option value="October">October</option>
                            <option value="November">November</option>
                            <option value="December">December</option>
                          </select>
                        </td>
                        <td>
                          <select name="from_jobyear3" id="from_jobyear3">
                            <option disabled value="0" selected>----</option>
                            <option value="2000">2000</option>
                            <option value="1999">1999</option>
                            <option value="1998">1998</option>
                            <option value="1997">1997</option>
                            <option value="1996">1996</option>
                            <option value="1995">1995</option>
                            <option value="1994">1994</option>
                            <option value="1993">1993</option>
                            <option value="1992">1992</option>
                            <option value="1991">1991</option>
                            <option value="1990">1990</option>
                            <option value="1989">1989</option>
                            <option value="1988">1988</option>
                            <option value="1987">1987</option>
                            <option value="1986">1986</option>
                            <option value="1985">1985</option>
                            <option value="1984">1984</option>
                            <option value="1983">1983</option>
                            <option value="1982">1982</option>
                            <option value="1981">1981</option>
                            <option value="1980">1980</option>
                            <option value="1979">1979</option>
                            <option value="1978">1978</option>
                            <option value="1977">1977</option>
                            <option value="1976">1976</option>
                            <option value="1975">1975</option>
                            <option value="1974">1974</option>
                            <option value="1973">1973</option>
                            <option value="1972">1972</option>
                            <option value="1971">1971</option>
                            <option value="1970">1970</option>
                            <option value="1969">1969</option>
                            <option value="1968">1968</option>
                            <option value="1967">1967</option>
                            <option value="1966">1966</option>
                            <option value="1965">1965</option>
                            <option value="1964">1964</option>
                            <option value="1963">1963</option>
                            <option value="1962">1962</option>
                            <option value="1961">1961</option>
                            <option value="1960">1960</option>
                            <option value="1959">1959</option>
                            <option value="1958">1958</option>
                            <option value="1957">1957</option>
                            <option value="1956">1956</option>
                          </select>
                        </td>
                        <td>
                          <select name="to_jobmonth3" id="to_jobmonth3">
                            <option disabled value="0" selected>----</option>
                            <option value="January">January</option>
                            <option value="February">February</option>
                            <option value="March">March</option>
                            <option value="April">April</option>
                            <option value="May">May</option>
                            <option value="June">June</option>
                            <option value="July">July</option>
                            <option value="August">August</option>
                            <option value="September">September</option>
                            <option value="October">October</option>
                            <option value="November">November</option>
                            <option value="December">December</option>
                          </select>
                        </td>
                        <td>
                          <select name="to_jobyear3" id="to_jobyear3">
                            <option disabled value="0" selected>----</option>
                            <option value="2000">2000</option>
                            <option value="1999">1999</option>
                            <option value="1998">1998</option>
                            <option value="1997">1997</option>
                            <option value="1996">1996</option>
                            <option value="1995">1995</option>
                            <option value="1994">1994</option>
                            <option value="1993">1993</option>
                            <option value="1992">1992</option>
                            <option value="1991">1991</option>
                            <option value="1990">1990</option>
                            <option value="1989">1989</option>
                            <option value="1988">1988</option>
                            <option value="1987">1987</option>
                            <option value="1986">1986</option>
                            <option value="1985">1985</option>
                            <option value="1984">1984</option>
                            <option value="1983">1983</option>
                            <option value="1982">1982</option>
                            <option value="1981">1981</option>
                            <option value="1980">1980</option>
                            <option value="1979">1979</option>
                            <option value="1978">1978</option>
                            <option value="1977">1977</option>
                            <option value="1976">1976</option>
                            <option value="1975">1975</option>
                            <option value="1974">1974</option>
                            <option value="1973">1973</option>
                            <option value="1972">1972</option>
                            <option value="1971">1971</option>
                            <option value="1970">1970</option>
                            <option value="1969">1969</option>
                            <option value="1968">1968</option>
                            <option value="1967">1967</option>
                            <option value="1966">1966</option>
                            <option value="1965">1965</option>
                            <option value="1964">1964</option>
                            <option value="1963">1963</option>
                            <option value="1962">1962</option>
                            <option value="1961">1961</option>
                            <option value="1960">1960</option>
                            <option value="1959">1959</option>
                            <option value="1958">1958</option>
                            <option value="1957">1957</option>
                            <option value="1956">1956</option>
                          </select>
                        </td>
                        <td><input type="text" style="width:200px;" name="employer3" id="employer3"></td>
                        <td><input type="text" style="width:200px;" name="employeradd3" id="employeradd3"></td>
                        <td><input type="text" style="width:160px;" name="pos3" id="pos3"></td>
                        <td><input type="text" style="width:170px;" name="job3" id="job3"></td>
                    </tr>
                    <tr id="emp4" name="emp4">
                        <td>
                          <select name="from_jobmonth4" id="from_jobmonth4">
                            <option disabled value="0" selected>----</option>
                            <option value="January">January</option>
                            <option value="February">February</option>
                            <option value="March">March</option>
                            <option value="April">April</option>
                            <option value="May">May</option>
                            <option value="June">June</option>
                            <option value="July">July</option>
                            <option value="August">August</option>
                            <option value="September">September</option>
                            <option value="October">October</option>
                            <option value="November">November</option>
                            <option value="December">December</option>
                          </select>
                        </td>
                        <td>
                          <select name="from_jobyear4" id="from_jobyear4">
                            <option disabled value="0" selected>----</option>
                            <option value="2000">2000</option>
                            <option value="1999">1999</option>
                            <option value="1998">1998</option>
                            <option value="1997">1997</option>
                            <option value="1996">1996</option>
                            <option value="1995">1995</option>
                            <option value="1994">1994</option>
                            <option value="1993">1993</option>
                            <option value="1992">1992</option>
                            <option value="1991">1991</option>
                            <option value="1990">1990</option>
                            <option value="1989">1989</option>
                            <option value="1988">1988</option>
                            <option value="1987">1987</option>
                            <option value="1986">1986</option>
                            <option value="1985">1985</option>
                            <option value="1984">1984</option>
                            <option value="1983">1983</option>
                            <option value="1982">1982</option>
                            <option value="1981">1981</option>
                            <option value="1980">1980</option>
                            <option value="1979">1979</option>
                            <option value="1978">1978</option>
                            <option value="1977">1977</option>
                            <option value="1976">1976</option>
                            <option value="1975">1975</option>
                            <option value="1974">1974</option>
                            <option value="1973">1973</option>
                            <option value="1972">1972</option>
                            <option value="1971">1971</option>
                            <option value="1970">1970</option>
                            <option value="1969">1969</option>
                            <option value="1968">1968</option>
                            <option value="1967">1967</option>
                            <option value="1966">1966</option>
                            <option value="1965">1965</option>
                            <option value="1964">1964</option>
                            <option value="1963">1963</option>
                            <option value="1962">1962</option>
                            <option value="1961">1961</option>
                            <option value="1960">1960</option>
                            <option value="1959">1959</option>
                            <option value="1958">1958</option>
                            <option value="1957">1957</option>
                            <option value="1956">1956</option>
                          </select>
                        </td>
                        <td>
                          <select name="to_jobmonth4" id="to_jobmonth4">
                            <option disabled value="0" selected>----</option>
                            <option value="January">January</option>
                            <option value="February">February</option>
                            <option value="March">March</option>
                            <option value="April">April</option>
                            <option value="May">May</option>
                            <option value="June">June</option>
                            <option value="July">July</option>
                            <option value="August">August</option>
                            <option value="September">September</option>
                            <option value="October">October</option>
                            <option value="November">November</option>
                            <option value="December">December</option>
                          </select>
                        </td>
                        <td>
                          <select name="to_jobyear4" id="to_jobyear4">
                            <option disabled value="0" selected>----</option>
                            <option value="2000">2000</option>
                            <option value="1999">1999</option>
                            <option value="1998">1998</option>
                            <option value="1997">1997</option>
                            <option value="1996">1996</option>
                            <option value="1995">1995</option>
                            <option value="1994">1994</option>
                            <option value="1993">1993</option>
                            <option value="1992">1992</option>
                            <option value="1991">1991</option>
                            <option value="1990">1990</option>
                            <option value="1989">1989</option>
                            <option value="1988">1988</option>
                            <option value="1987">1987</option>
                            <option value="1986">1986</option>
                            <option value="1985">1985</option>
                            <option value="1984">1984</option>
                            <option value="1983">1983</option>
                            <option value="1982">1982</option>
                            <option value="1981">1981</option>
                            <option value="1980">1980</option>
                            <option value="1979">1979</option>
                            <option value="1978">1978</option>
                            <option value="1977">1977</option>
                            <option value="1976">1976</option>
                            <option value="1975">1975</option>
                            <option value="1974">1974</option>
                            <option value="1973">1973</option>
                            <option value="1972">1972</option>
                            <option value="1971">1971</option>
                            <option value="1970">1970</option>
                            <option value="1969">1969</option>
                            <option value="1968">1968</option>
                            <option value="1967">1967</option>
                            <option value="1966">1966</option>
                            <option value="1965">1965</option>
                            <option value="1964">1964</option>
                            <option value="1963">1963</option>
                            <option value="1962">1962</option>
                            <option value="1961">1961</option>
                            <option value="1960">1960</option>
                            <option value="1959">1959</option>
                            <option value="1958">1958</option>
                            <option value="1957">1957</option>
                            <option value="1956">1956</option>
                          </select>
                        </td>
                        <td><input type="text" style="width:200px;" name="employer4" id="employer4"></td>
                        <td><input type="text" style="width:200px;" name="employeradd4" id="employeradd4"></td>
                        <td><input type="text" style="width:160px;" name="pos4" id="pos4"></td>
                        <td><input type="text" style="width:170px;" name="job4" id="job4"></td>
                    </tr>
                    <tr id="emp5" name="emp5">
                        <td>
                          <select name="from_jobmonth5" id="from_jobmonth5">
                            <option disabled value="0" selected>----</option>
                            <option value="January">January</option>
                            <option value="February">February</option>
                            <option value="March">March</option>
                            <option value="April">April</option>
                            <option value="May">May</option>
                            <option value="June">June</option>
                            <option value="July">July</option>
                            <option value="August">August</option>
                            <option value="September">September</option>
                            <option value="October">October</option>
                            <option value="November">November</option>
                            <option value="December">December</option>
                          </select>
                        </td>
                        <td>
                          <select name="from_jobyear5" id="from_jobyear5">
                            <option disabled value="0" selected>----</option>
                            <option value="2000">2000</option>
                            <option value="1999">1999</option>
                            <option value="1998">1998</option>
                            <option value="1997">1997</option>
                            <option value="1996">1996</option>
                            <option value="1995">1995</option>
                            <option value="1994">1994</option>
                            <option value="1993">1993</option>
                            <option value="1992">1992</option>
                            <option value="1991">1991</option>
                            <option value="1990">1990</option>
                            <option value="1989">1989</option>
                            <option value="1988">1988</option>
                            <option value="1987">1987</option>
                            <option value="1986">1986</option>
                            <option value="1985">1985</option>
                            <option value="1984">1984</option>
                            <option value="1983">1983</option>
                            <option value="1982">1982</option>
                            <option value="1981">1981</option>
                            <option value="1980">1980</option>
                            <option value="1979">1979</option>
                            <option value="1978">1978</option>
                            <option value="1977">1977</option>
                            <option value="1976">1976</option>
                            <option value="1975">1975</option>
                            <option value="1974">1974</option>
                            <option value="1973">1973</option>
                            <option value="1972">1972</option>
                            <option value="1971">1971</option>
                            <option value="1970">1970</option>
                            <option value="1969">1969</option>
                            <option value="1968">1968</option>
                            <option value="1967">1967</option>
                            <option value="1966">1966</option>
                            <option value="1965">1965</option>
                            <option value="1964">1964</option>
                            <option value="1963">1963</option>
                            <option value="1962">1962</option>
                            <option value="1961">1961</option>
                            <option value="1960">1960</option>
                            <option value="1959">1959</option>
                            <option value="1958">1958</option>
                            <option value="1957">1957</option>
                            <option value="1956">1956</option>
                          </select>
                        </td>
                        <td>
                          <select name="to_jobmonth5" id="to_jobmonth5">
                            <option disabled value="0" selected>----</option>
                            <option value="January">January</option>
                            <option value="February">February</option>
                            <option value="March">March</option>
                            <option value="April">April</option>
                            <option value="May">May</option>
                            <option value="June">June</option>
                            <option value="July">July</option>
                            <option value="August">August</option>
                            <option value="September">September</option>
                            <option value="October">October</option>
                            <option value="November">November</option>
                            <option value="December">December</option>
                          </select>
                        </td>
                        <td>
                          <select name="to_jobyear5" id="to_jobyear5">
                            <option disabled value="0" selected>----</option>
                            <option value="2000">2000</option>
                            <option value="1999">1999</option>
                            <option value="1998">1998</option>
                            <option value="1997">1997</option>
                            <option value="1996">1996</option>
                            <option value="1995">1995</option>
                            <option value="1994">1994</option>
                            <option value="1993">1993</option>
                            <option value="1992">1992</option>
                            <option value="1991">1991</option>
                            <option value="1990">1990</option>
                            <option value="1989">1989</option>
                            <option value="1988">1988</option>
                            <option value="1987">1987</option>
                            <option value="1986">1986</option>
                            <option value="1985">1985</option>
                            <option value="1984">1984</option>
                            <option value="1983">1983</option>
                            <option value="1982">1982</option>
                            <option value="1981">1981</option>
                            <option value="1980">1980</option>
                            <option value="1979">1979</option>
                            <option value="1978">1978</option>
                            <option value="1977">1977</option>
                            <option value="1976">1976</option>
                            <option value="1975">1975</option>
                            <option value="1974">1974</option>
                            <option value="1973">1973</option>
                            <option value="1972">1972</option>
                            <option value="1971">1971</option>
                            <option value="1970">1970</option>
                            <option value="1969">1969</option>
                            <option value="1968">1968</option>
                            <option value="1967">1967</option>
                            <option value="1966">1966</option>
                            <option value="1965">1965</option>
                            <option value="1964">1964</option>
                            <option value="1963">1963</option>
                            <option value="1962">1962</option>
                            <option value="1961">1961</option>
                            <option value="1960">1960</option>
                            <option value="1959">1959</option>
                            <option value="1958">1958</option>
                            <option value="1957">1957</option>
                            <option value="1956">1956</option>
                          </select></td>
                        <td><input type="text" style="width:200px;" name="employer5" id="employer5"></td>
                        <td><input type="text" style="width:200px;" name="employeradd5" id="employeradd5"></td>
                        <td><input type="text" style="width:160px;" name="pos5" id="pos5"></td>
                        <td><input type="text" style="width:170px;" name="job5" id="job5"></td>
                    </tr>
                    <tr id="emp6" name="emp6">
                        <td>
                          <select name="from_jobmonth6" id="from_jobmonth6">
                            <option disabled value="0" selected>----</option>
                            <option value="January">January</option>
                            <option value="February">February</option>
                            <option value="March">March</option>
                            <option value="April">April</option>
                            <option value="May">May</option>
                            <option value="June">June</option>
                            <option value="July">July</option>
                            <option value="August">August</option>
                            <option value="September">September</option>
                            <option value="October">October</option>
                            <option value="November">November</option>
                            <option value="December">December</option>
                          </select></td>
                        <td>
                          <select name="from_jobyear6" id="from_jobyear6">
                            <option disabled value="0" selected>----</option>
                            <option value="2000">2000</option>
                            <option value="1999">1999</option>
                            <option value="1998">1998</option>
                            <option value="1997">1997</option>
                            <option value="1996">1996</option>
                            <option value="1995">1995</option>
                            <option value="1994">1994</option>
                            <option value="1993">1993</option>
                            <option value="1992">1992</option>
                            <option value="1991">1991</option>
                            <option value="1990">1990</option>
                            <option value="1989">1989</option>
                            <option value="1988">1988</option>
                            <option value="1987">1987</option>
                            <option value="1986">1986</option>
                            <option value="1985">1985</option>
                            <option value="1984">1984</option>
                            <option value="1983">1983</option>
                            <option value="1982">1982</option>
                            <option value="1981">1981</option>
                            <option value="1980">1980</option>
                            <option value="1979">1979</option>
                            <option value="1978">1978</option>
                            <option value="1977">1977</option>
                            <option value="1976">1976</option>
                            <option value="1975">1975</option>
                            <option value="1974">1974</option>
                            <option value="1973">1973</option>
                            <option value="1972">1972</option>
                            <option value="1971">1971</option>
                            <option value="1970">1970</option>
                            <option value="1969">1969</option>
                            <option value="1968">1968</option>
                            <option value="1967">1967</option>
                            <option value="1966">1966</option>
                            <option value="1965">1965</option>
                            <option value="1964">1964</option>
                            <option value="1963">1963</option>
                            <option value="1962">1962</option>
                            <option value="1961">1961</option>
                            <option value="1960">1960</option>
                            <option value="1959">1959</option>
                            <option value="1958">1958</option>
                            <option value="1957">1957</option>
                            <option value="1956">1956</option>
                          </select>
                        </td>
                        <td>
                          <select name="to_jobmonth6" id="to_jobmonth6">
                            <option disabled value="0" selected>----</option>
                            <option value="January">January</option>
                            <option value="February">February</option>
                            <option value="March">March</option>
                            <option value="April">April</option>
                            <option value="May">May</option>
                            <option value="June">June</option>
                            <option value="July">July</option>
                            <option value="August">August</option>
                            <option value="September">September</option>
                            <option value="October">October</option>
                            <option value="November">November</option>
                            <option value="December">December</option>
                          </select>
                        </td>
                        <td>
                          <select name="to_jobyear6" id="to_jobyear6">
                            <option disabled value="0" selected>----</option>
                            <option value="2000">2000</option>
                            <option value="1999">1999</option>
                            <option value="1998">1998</option>
                            <option value="1997">1997</option>
                            <option value="1996">1996</option>
                            <option value="1995">1995</option>
                            <option value="1994">1994</option>
                            <option value="1993">1993</option>
                            <option value="1992">1992</option>
                            <option value="1991">1991</option>
                            <option value="1990">1990</option>
                            <option value="1989">1989</option>
                            <option value="1988">1988</option>
                            <option value="1987">1987</option>
                            <option value="1986">1986</option>
                            <option value="1985">1985</option>
                            <option value="1984">1984</option>
                            <option value="1983">1983</option>
                            <option value="1982">1982</option>
                            <option value="1981">1981</option>
                            <option value="1980">1980</option>
                            <option value="1979">1979</option>
                            <option value="1978">1978</option>
                            <option value="1977">1977</option>
                            <option value="1976">1976</option>
                            <option value="1975">1975</option>
                            <option value="1974">1974</option>
                            <option value="1973">1973</option>
                            <option value="1972">1972</option>
                            <option value="1971">1971</option>
                            <option value="1970">1970</option>
                            <option value="1969">1969</option>
                            <option value="1968">1968</option>
                            <option value="1967">1967</option>
                            <option value="1966">1966</option>
                            <option value="1965">1965</option>
                            <option value="1964">1964</option>
                            <option value="1963">1963</option>
                            <option value="1962">1962</option>
                            <option value="1961">1961</option>
                            <option value="1960">1960</option>
                            <option value="1959">1959</option>
                            <option value="1958">1958</option>
                            <option value="1957">1957</option>
                            <option value="1956">1956</option>
                          </select>
                        </td>
                        <td><input type="text" style="width:200px;" name="employer6" id="employer6"></td>
                        <td><input type="text" style="width:200px;" name="employeradd6" id="employeradd6"></td>
                        <td><input type="text" style="width:160px;" name="pos6" id="pos6"></td>
                        <td><input type="text" style="width:170px;" name="job6" id="job6"></td>
                    </tr>
                </table><br/><br/>
                </div>

                <label class="col-sm-2 col-form-label"><h5>This sub-section should be filled in if the applicant is sponsored by the Employer.</h5></label>&nbsp;&nbsp;&nbsp;
                <label for="employername">Name of Employer</label>
                <input type="text" name="employername" id="employername" style="width:250px;"/>&nbsp;&nbsp;
                <label for="employernum">Phone No. of Employer</label>
                <input type="text" name="employernum" id="employernum"/><br/><br/>&nbsp;&nbsp;
                <label for="ticksponsor">(Choose as appropriate)&nbsp;&nbsp;&nbsp;</label>
                <input type='radio' name='sponsor' id='sponsored' value='Sponsored' checked />Sponsored&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <input type='radio' name='sponsor' id='released' value='Released'/>Released&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <input type='radio' name='sponsor' id='inprocess' value='Release in process'/>Release in process<br/>
                <h6>Note: A Sponsored Applicant is one who will be released and the payment will be settled by the Employer</h6>

              </div>

              <div>
                Have you any particular career in view?<br/>
                <input type='radio' name='career' id='yes' value='Yes'/>Yes&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <input type='radio' name='career' id='no' value='No' checked/>No&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<br/>
                <p id="careerinview" style="display:none;">If so, specify:&nbsp;<input type="text" name="specifycareer" id="specifycareer" style="width:250px;" /></p><br/>
              </div>
              &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <button id="next4" name="next4">Next</button>
            </div>
            

            <div id="box4" class="tab-pane fade">
              <div class="form-group row">
                <label class="col-sm-2 col-form-label">Referees<br/><h5>(Please obtain their prior agreement. The University of Technology, Mauritius may write to them if you are shortlisted</h5></label>
                <div id="ref1" style="display:inline-block;margin-right:100px;">
                    <u>Referee 1</u><br/>
                    Name<input type="text" name="ref1name" id="ref1name" style="margin-left:50px;" /><br/>
                    Occupation&nbsp;<input type="text" name="ref1occ" id="ref1occ" style="margin-left:10px;" /><br/>
                    Address&nbsp;<input type="text" name="ref1add" id="ref1add" style="margin-left:32px;" /><br/>
                    Phone No.&nbsp;<input type="text" name="ref1num" id="ref1num" style="margin-left:15px;">
                </div>
                <div id="ref2" style="display:inline-block;">
                    <u>Referee 2</u><br/>
                    Name<input type="text" name="ref2name" id="ref2name" style="margin-left:50px;" /><br/>
                    Occupation&nbsp;<input type="text" name="ref2occ" id="ref2occ" style="margin-left:10px;" /><br/>
                    Address&nbsp;<input type="text" name="ref2add" id="ref2add" style="margin-left:32px;" /><br/>
                    Phone No.&nbsp;<input type="text" name="ref2num" id="ref2num" style="margin-left:15px;">
                </div>
              </div>
              <button id="next5" name="next5">Next</button>
            </div>

            <div id="box5" class="tab-pane fade">
              <div id="under18" class="form-group row">
                <label class="col-sm-2 col-form-label">This section should be filled in if you are under 18 years of age.</label><br/><br/>
                  <div class="col-sm-10">
                    <input type="checkbox" id="parent_agree" name="parent_agree" value="U18_parentagree">I agree to be bound with him/her for the execution thereof.<br/><br/><br/>
                    <p id="parent_details" style="display:none;">
                        Name of parent/guardian&nbsp;<input type="text" name="parentname" style="width:240px;" id="parentname"/><br/><br/>
                        Phone No.(ifany)&nbsp;&nbsp;&nbsp;&nbsp;Home:<input type="text" name="parenthome" id="parenthome"><br/><br/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        Office:<input type="text" name="parentoffice" id="parentoffice"><br/><br/>
                        Address&nbsp;<input type="text" name="parentaddress" style="width:240px; margin-left:120px;" id="parentaddress"><br/><br/>
                        Occupation&nbsp;<input type="text" style="width:225px; margin-left:95px;" name="parentoccupation" id="parentoccupation">
                    </p>
                  </div>
                  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                  <button id="next6" name="next6">Next</button>
              </div>              
            </div>

            <div id="box6" class="tab-pane fade">
            <br/>
              <div>I, <input type="text" style="width:220px;" name="rulesname" id="rulesname">, solemly declare that if admitted to the University of Technology, Mauritius, I will<br/>
                <ol type="a">
                    <li> diligently follow the Programme of study for which I am selected to its termination;</li>
                    <li> inform the Registrar, in writing and without delay, if I withdraw from the Programme;</li>
                    <li> comply to all the rules and regulations of the University of Technology, Mauritius;</li>
                    <li> pay in advance all fees and dues required until the completion of studies.</li>
                    <li> incur the cost of recovering any additional outstanding balance due to the University will be borne by the student.</li>
                    <li> Inform Registrar if am suffering from any illness or incapacity.</li>
                </ol>
              </div>
              <br/><br/><br/><br/>
              <div><input type="checkbox"  name="declare" id="declare">&nbsp;<b>I also declare that the above information is true and correct.</b></div><br/><br/>

              <b id="disp2">Date : <div id="disp"></div></b>
              <input type="hidden" name="todaysdate" id="todaysdate"><br/><br/>

              <button type="submit" id="btnSubmit" name="btnSubmit">Submit Form</button>
            </div>



            </div>
         
          <br/>				
				
				</div>
			  <div class="clearfix"> </div>
			</div>
		</div>
	</div>
	<!-- //events -->
<!-- footer -->
	<?php include("footer.php");?>

<!-- //footer -->

  
<!-- for bootstrap working -->
	<script src="js/bootstrap.js"></script>
<!-- //for bootstrap working -->
<!-- here stars scrolling icon -->
	<script type="text/javascript">
	
		$(document).ready(function() {
							
			$().UItoTop({ easingType: 'easeOutQuart' });
			
		});
			
	</script>
				
</body>
</html>

<?php
include("db.php");

//prevent sql injection
$FName=mysqli_real_escape_string($mysqli,$_POST["lfname"]);
$LName=mysqli_real_escape_string($mysqli,$_POST["llname"]);
$DOB=mysqli_real_escape_string($mysqli,$_POST["ldob"]);
$NIC=mysqli_real_escape_string($mysqli,$_POST["lNIC"]);
$tel=mysqli_real_escape_string($mysqli,$_POST["ltel"]);	
$mob=mysqli_real_escape_string($mysqli,$_POST["lmob"]);
$marital=($_POST["status"]);
$gender=($_POST["gender"]);
$address=($_POST["lsublocality"]);
$email=mysqli_real_escape_string($mysqli,$_POST["lmail"]);

function passFunc($len,$set="")
{
  $gen="";
  for($i=0;$i<$len;$i++)
	{
		$set= str_shuffle($set);
         $gen .=$set[0];									
	 }
	  return $gen;
}
$lpass= passFunc(8,'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ123456789'); 
							  
							
$pw= $lpass;
$mode=($_POST["mode"]);
$dept; 
$postn;

if(!isset($_POST["lposition"])){
	$postn = "Lecturer";
}
else 
{
	$postn = ($_POST["lposition"]);
}

if(!isset($_POST["ldept"])){
	$dept = "11";
}
else 
{
	$dept = ($_POST["ldept"]);
	
}

$salt="ikrngngrngikrwngik925820496802986002+325i925fkjskjng";
$passwrd=$pw.$salt;
$hashed_pw=hash("sha512",$passwrd,true);
$pwencr= password_hash($hashed_pw,PASSWORD_DEFAULT,['salt' => mcrypt_create_iv(22, MCRYPT_DEV_URANDOM)]);
 


	//check if user exist already
	$query="select * from tbltutor where TEmail='$email' and TNIC='$NIC'";
	$result=mysqli_query($mysqli,$query) or die('error');
	if (mysqli_num_rows($result))
	{
	     echo('Email Already registered!!');
		 exit();
	}
   else{
     
		require 'PHPMailerAutoload.php';

		$mail = new PHPMailer;
		$mail->isSMTP();
		$mail->SMTPAuth = true;
		$mail->Host = 'smtp.gmail.com';
		$mail->Port = 465;
		//Username to use for SMTP authentication - use full email address for gmail
		$mail->Username = "Sakeenah2492650@gmail.com";
		//Password to use for SMTP authentication
		$mail->Password = "sakeenah123";
		//Set the encryption system to use - ssl (deprecated) or tls
		$mail->SMTPSecure = 'ssl';
		//Set who the message is to be sent from
		$mail->setFrom('Sakeenah2492650@gmail','University Technology of Mauritius');
		//Set an alternative reply-to address
		$mail->addReplyTo('Sakeenah2492650@gmail', 'University Technology of Mauritius');
		//Set who the message is to be sent to
		$mail->addAddress($email, $FName);
		//Set the subject line
		$mail->Subject = 'Registration to UTM Website';
		$mail->isHTML(true);
		$mail->Body ='<div style="width: 640px; font-family: Arial, Helvetica, sans-serif; font-size: 11px;">
		  <h1>You have been registered to the UTM Website.</h1>
		  <div align="center">
			<a href="localhost:8080/UTM/index.php"><img src="UTM.png" height="90" width="340" ></a>
		  </div>

		  <p>Your Username:'.$email.'</p>
		  <p>Your password:'.$pw.'</p>
		  <p>You are advise to change your password for security reason</p>
		  <p><a href="localhost:8080/UTM/login.php"><u>Click here to login</u></a></p>
		</div>';
		//Replace the plain text body with one created manually
		$mail->AltBody = 'This is a plain-text message body';
	 
	 
    $query="INSERT into tbltutor (TFName,TLName,TEmail,SublocalityID,DOB,Tmode,TPhone,TMobile,TPassword,Tstatus,TMarital_Sta,TSex,Dept_ID,Tpositn,TDate_reg,TNIC) values ('$FName','$LName','$email','$address','$DOB','$mode','$tel','$mob','$pwencr','active','$marital','$gender','$dept','$postn',now(),'$NIC')";
	
	$mail_send = $mail->send();
	
	 if(!$mail_send){
		
		echo "Please check your internet Connection and try again!";
		exit();
	}
	if((mysqli_query($mysqli,$query))& ($mail_send))
	{
		
		// redirect to success page
		echo "Registered!!";
		exit();
			
	}
	else
	{
		echo("Error description: " . mysqli_error($mysqli));
		

	}
	
	
	
	
}
?>
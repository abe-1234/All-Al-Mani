 <?php 
include "db.php";
include "PHPExcel/IOFactory.php";


//$message = '';
$sid;
 $semdes;

if(isset($_POST['import']))
{  

  $semdes =  mysqli_real_escape_string($mysqli,$_POST['semDes']);
  
   if(!$semdes)
   {
	   echo "<script>window.location.href = 'timetable.php';alert('Description required!!');</script>";
	   exit();
   }
   
	$ext = $_FILES['filename']['name'];
	
	$pth = pathinfo($ext,PATHINFO_EXTENSION);
	
	 if($pth == 'xls')
	 {   
        
		 $query = "SELECT S_description FROM tblsemester WHERE S_description = '".$semdes."' ";
		$result = mysqli_query($mysqli,$query);
		$num = mysqli_num_rows($result);
		if($num > 0)
		{
			echo "<script>window.location.href = 'timetable.php'; alert('Timetable is already been posted');</script>";
			exit();
		}
		
		else 
		{
          
         // select last id of semester so as to set it inactive when new one is inserted
          $sql = "SELECT MAX(Semester_ID) FROM tblsemester";
		  $query = mysqli_query($mysqli, $sql);
		  $row = mysqli_fetch_row($query);
		  $lastid = $row[0];
		  
			 
			 if ($lastid !== '')
			 {
				 //update last semester set it inactive 
				$query = "UPDATE tblsemester SET S_status = 'inactive' WHERE Semester_ID = '".$lastid."' ";
				 if(!mysqli_query($mysqli,$query))
				 {
					 echo("<script>window.location.href = 'timetable.php'; alert('Error description:".mysqli_error($mysqli)."');</script>");
					 exit();
				 }
				 else 
				 {
					 
					 //insert semester description into its table
					$query = "INSERT INTO tblsemester (S_description,S_status) VALUES ('".mysqli_real_escape_string($mysqli,$_POST['semDes'])."','active')";
					
					if (!mysqli_query($mysqli,$query))
						{
							echo("<script>window.location.href = 'timetable.php'; alert('Error description:".mysqli_error($mysqli)."');</script>");
							exit();

						}
						else
						{
							
							$sid = mysqli_insert_id($mysqli);
							
						}
			
				 }
		 
			 
			
			 // $ms = -((3600*4)+6);
			// $today_date =  gmdate("m/d/Y h:i:s A", time()-($ms));
			
			// set last timetable inactive
			   
			   $query = "UPDATE tbltimetable SET Status = 'inactive' WHERE Semester_ID = '".$lastid."' ";
				 mysqli_query($mysqli,$query);
		
		  }
		  else
		  {
			   //insert semester description into its table
					$query = "INSERT INTO tblsemester (S_description,S_status) VALUES ('".mysqli_real_escape_string($mysqli,$_POST['semDes'])."','active')";
					
					if (!mysqli_query($mysqli,$query))
						{
							echo("<script>window.location.href = 'timetable.php'; alert('Error description:".mysqli_error($mysqli)."');</script>");

						}
						else
						{
							
							$sid = mysqli_insert_id($mysqli);
							
						}
		  }
		  
		 $pthfile = "up_Lect_Ttbl/".$_FILES['filename']['name'];
		 move_uploaded_file($_FILES['filename']['tmp_name'],"up_Lect_Ttbl/".$_FILES['filename']['name']);
		 
		
		    
	        //extract values from excel sheet timetable
		    $objPHPExcel = PHPExcel_IOFactory::load($pthfile);
			 foreach($objPHPExcel->getWorksheetIterator() as $worksheet)
			 {
				 $highestRow = $worksheet->getHighestRow();
				 
				 for($row=12; $row<=$highestRow; $row++)
				 {
					//$progName = mysqli_real_escape_string($mysqli,$worksheet->getCellByColumnAndRow(1,$row)->getValue()); 
					$cohort = mysqli_real_escape_string($mysqli,$worksheet->getCellByColumnAndRow(2,$row)->getValue());
					$studnum = mysqli_real_escape_string($mysqli,$worksheet->getCellByColumnAndRow(3,$row)->getValue());
					$moduleCode = mysqli_real_escape_string($mysqli,$worksheet->getCellByColumnAndRow(4,$row)->getValue()); 				
					$headDept = mysqli_real_escape_string($mysqli,$worksheet->getCellByColumnAndRow(5,$row)->getValue()); 
					$progDir = mysqli_real_escape_string($mysqli,$worksheet->getCellByColumnAndRow(6,$row)->getValue());
					$progCoord = mysqli_real_escape_string($mysqli,$worksheet->getCellByColumnAndRow(7,$row)->getValue()); 				
					$ltp = mysqli_real_escape_string($mysqli,$worksheet->getCellByColumnAndRow(9,$row)->getValue());
					$mode = mysqli_real_escape_string($mysqli,$worksheet->getCellByColumnAndRow(10,$row)->getValue()); 				
					$Surname = mysqli_real_escape_string($mysqli,$worksheet->getCellByColumnAndRow(11,$row)->getValue()); 
					$Name = mysqli_real_escape_string($mysqli,$worksheet->getCellByColumnAndRow(12,$row)->getValue());
					$title = mysqli_real_escape_string($mysqli,$worksheet->getCellByColumnAndRow(13,$row)->getValue());
					$lday = mysqli_real_escape_string($mysqli,$worksheet->getCellByColumnAndRow(15,$row)->getValue()); 				
					$ltime = mysqli_real_escape_string($mysqli,$worksheet->getCellByColumnAndRow(16,$row)->getValue()); 
					$lvenue = mysqli_real_escape_string($mysqli,$worksheet->getCellByColumnAndRow(17,$row)->getValue());
					$pday = mysqli_real_escape_string($mysqli,$worksheet->getCellByColumnAndRow(18,$row)->getValue()); 				
					$ptime = mysqli_real_escape_string($mysqli,$worksheet->getCellByColumnAndRow(19,$row)->getValue()); 
					$pvenue = mysqli_real_escape_string($mysqli,$worksheet->getCellByColumnAndRow(20,$row)->getValue());
					$remark = mysqli_real_escape_string($mysqli,$worksheet->getCellByColumnAndRow(21,$row)->getValue()); 

                    
				  
				   //Extract tutorid from surname and name
                  $sql = "SELECT Tutor_ID FROM tbltutor WHERE TFName='".$Name."' AND TLName='".$Surname."'";
				  $query = mysqli_query($mysqli, $sql);
				  $row2 = mysqli_fetch_row($query);
				  $tutorid = $row2[0];
				  
				 //Extract lto,pto,lfrom,pfrom
                  $pfrom = substr($ptime,0,5);
				  $pto =  substr($ptime,6);				 
				 
				  $lfrom = substr($ltime,0,5);
				  $lto =  substr($ltime,6);
				  
				  //Insert timetable now
				  $query3 = "INSERT INTO tbltimetable (Cohort_ID,M_code,Semester_ID,Title,Tutor_ID,No_of_Stud,HeadDept,ProgDirect,ProgCoord,LTP,mode,LDay,LTo,LFrom,LRoom,PDay,PTo,PFrom,PRoom,Status,Remark,Date_updated) VALUES ('".$cohort."','".$moduleCode."','".$sid."','".$title."','".$tutorid."','".$studnum."','".$headDept."','".$progDir."','".$progCoord."','".$ltp."','".$mode."','".$lday."','".$lto."','".$lfrom."','".$lvenue."','".$pday."','".$pto."','".$pfrom."','".$pvenue."','active','".$remark."',now())";
					 // mysqli_query($mysqli,$query3);
					 if (!mysqli_query($mysqli,$query3))
						{
							echo("<script>window.location.href = 'timetable.php'; alert('Error description:".mysqli_error($mysqli)."');</script>");

						}
					else{
						echo "<script>window.location.href = 'timetable.php'; alert('Timetable has been posted');</script>";
					}
				  
					
				 }
				 

				
			 }
		  
		 
		
		
		}
			
				
		
		
		
	   }		
		 
		 
    

	 else 
	 {
		 echo "<script>window.location.href = 'timetable.php'; alert('Only Excel file is accepted');</script>";
		 
	 }
	
// switch($_FILES['filename']['error'])
// {
	
	// case 2:
	      // $message = $_FILES['filename']['name'].'  is too big to upload.';
		  
		  // break;
	// case 4:
	      // $message = 'No file selected.';
		  
		  // break;
	// default:
	      // $message ='Sorry, there was a problem uploading'. $_FILES['filename']['name'];
		  
		  // break;
// }	
// echo $message;	
}
 ?>
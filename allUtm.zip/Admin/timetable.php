<?php
include("session_admin.php");
?>
<!DOCTYPE html>
<html>
<head>
<title>Admin Portal</title>
<?php include("head.php");?>

</head>
	
<body>


<!-- header -->
	<?php include("menu.php");?>
	</br></br>
<!-- //header -->

<!-- events -->
	<div class="events">
		<div class="container">
			<h3><span>Timetable for Student and Lecturer</span></h3>
			<div class="events-grids">
			<div class="row">
			 <form action="<?php echo htmlspecialchars('uploadphp.php');?>"  enctype="multipart/form-data" role="form" method="POST" id="frmtimetable" >
			 <div class="form-group row">
				<label for="semDes" class="col-sm-2 col-form-label">Description of Semester</label>
				 <div class="col-sm-10">
					<input type="text" id="semDes"  name="semDes" placeholder="e.g Semester 1 & Semester 2 (2016/2017)" class="form-control">
				 </div>
			</div>
            <div class="form-group row">
				<label for="filename" class="col-sm-2 col-form-label">New Timetable</label>
				 <div class="col-sm-10">
				 <input type="file" name="filename" id="filename" class="form-control btn-secondary">
					
				 </div>
			</div>
			<div class="btn-group" style="float:right;">
						<button type="submit" name="import"  id="import" class="btn btn-info">Submit</button>
						<button type="reset" class="btn btn-danger">Cancel</button>
						</div> 
			</form>
			
				<div class="clearfix"> </div>
			</div>
		</div>
	</div>
 </div>
<!-- //events -->
<!-- footer -->
	<?php include("footer.php");?>

<!-- //footer -->
<script type="text/javascript">
	
		



		$(document).ready(function() {
			
			$( "#frmtimetable" ).validate( {
				rules: {
					semDes: {required:true
						
					        },
					filename: {required:true
						
					        }
				},
				messages: {
					semDes: {required:"Please enter a description"
						
					        },
					filename: {required:"Please choose a file"
						
					        }
					
				},
				ignore:":hidden",
				errorElement: "em",
				errorPlacement: function ( error, element ) {
					// Add the `help-block` class to the error element
					error.addClass( "help-block" );

					// Add `has-feedback` class to the parent div.form-group
					// in order to add icons to inputs
					element.parents( ".col-sm-10" ).addClass( "has-feedback" );

									if ( element.is(":radio") ) 
						{
							error.appendTo( element.parents('.col-sm-10') );
						}
						else
						{ // This is the default behavior 
							error.insertAfter( element );
						}

					// Add the span element, if doesn't exists, and apply the icon classes to it.
					if ( !element.next( "span" )[ 0 ] ) {
						$( "<span class='glyphicon glyphicon-remove form-control-feedback'></span>" ).insertAfter( element );
					}
				},
				success: function ( label, element ) {
					// Add the span element, if doesn't exists, and apply the icon classes to it.
					if ( !$( element ).next( "span" )[ 0 ] ) {
						$( "<span class='glyphicon glyphicon-ok form-control-feedback'></span>" ).insertAfter( $( element ) );
					}
				},
				highlight: function ( element, errorClass, validClass ) {
					$( element ).parents( ".col-sm-10" ).addClass( "has-error" ).removeClass( "has-success" );
					$( element ).next( "span" ).addClass( "glyphicon-remove" ).removeClass( "glyphicon-ok" );
				},
				unhighlight: function ( element, errorClass, validClass ) {
					$( element ).parents( ".col-sm-10" ).addClass( "has-success" ).removeClass( "has-error" );
					$( element ).next( "span" ).addClass( "glyphicon-ok" ).removeClass( "glyphicon-remove" );
				}
			} );
			
		});
		
</script>
</body>

</html>
<?php
include("session_admin.php");
?>
<!DOCTYPE html>
<html>
<head>
<title>Admin Portal</title>
<?php include("head.php");?>

</head>
	
<body>


<!-- header -->
	<?php include("menu.php");?>
	</br></br>
<!-- //header -->

<!-- events -->
	<div class="events">
		<div class="container">
			<h3><span>HOMEPAGE</span></h3>
			<div class="events-grids">
			<div class="row">
			 

			
				<div class="clearfix"> </div>
			</div>
		</div>
	</div>
 </div>
<!-- //events -->
<!-- footer -->
	<?php include("footer.php");?>

<!-- //footer -->
<!-- Main JS  -->

<!-- //here ends scrolling icon -->
</body>

</html>
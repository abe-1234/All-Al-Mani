<?php
include "db.php";
$S_ID;
if(!isset($_POST['School1']))
{
	echo "Select a school first!!";
	exit();
}
else {
	$S_ID = $_POST['School1'];
}


$num = count($_POST["dept"]);
if($num >= 1) 
{ 
	for($i=0; $i<$num; $i++)
	{
		if($_POST["dept"][$i] != '')
		{
			$sql2 = "INSERT INTO tbldept (Dept_name,School_ID) VALUES ('".mysqli_real_escape_string($mysqli,$_POST["dept"][$i])."','".$S_ID."')";
           mysqli_query($mysqli, $sql2);
		   
		}
		else
		{
			echo "Enter Department";
			exit();
		}
	}
	echo "Departments have added successfully and the page will be refreshed in a few seconds";
	
	
}
else
{
	echo "Enter Department";
}

?>

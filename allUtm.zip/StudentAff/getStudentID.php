<?php
include("db.php");
$yr = date("Y");
$shrtyr = substr($yr,2,2);

$studid;

$query = "SELECT * FROM tblapplicant";
$result = mysqli_query($mysqli,$query);

$db_field = mysqli_fetch_assoc($result);
		
if((($db_field['StudentID']) =="") or (($db_field['StudentID']) == null))
{
	$id = "0001";
	$studid = $shrtyr.$id;
	echo $studid;
	exit();
	
}
else 
{
	$query1 = "SELECT MAX(StudentID) FROM tblapplicant";
    $result1 = mysqli_query($mysqli,$query1);
    $row=mysqli_fetch_row($result1);
	$lstid = $row[0];
	
	if(substr($lstid,0,2) == $shrtyr)
	{
		$studid = $lstid+1;
		echo $studid;
		exit();
		
	}
	else
	{
		$id = "0001";
	    $studid = $shrtyr.$id;
		echo $studid;
	}
}


?>
<?php
include("session_studentAff.php");
$id = htmlEntities($_GET['id']);
if(!$id)
{
  $_SESSION['login'] == false;
  session_destroy();
  echo "<script>window.location.href = '../UTM/login.php'</script>";
  exit();
}
// echo $id;
// exit();
?>

<!DOCTYPE html>
<html>
<head>

<style>
    a{
      font-size: 17px;
    }
  </style>
   
   <script type="text/javascript" src="js/ajax.js"></script>
  
  


  <!--<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">-->
  <!--<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>-->
  <!--<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>-->
   
   <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" media="all" />



<title>Student Affairs Portal</title>
<?php include("head.php");?>
<script type="text/javascript" src="js/jquery-2.1.4.min.js"></script>
<script type="text/javascript" src="js/jquery-1.11.1.js"></script>
<script>

function registerStud()
{
	var data1 = $('#studfrm').serialize();
                    $.ajax({
                        type: "POST",
                        url: "register_DB.php",
                        data: data1,
                        success: function(msg) {
                            alert(msg);
							if(msg == "Registered!!"){
								 window.location.href = 'Qualified_App.php';
								
								
								 
							}
							else if(msg == "Student is either not yet qualified for a course or have already been registered!!"){
								  window.location.href = 'Qualified_App.php';
							}
							
                          
							 
                           
                        }
                    });
}
 function getUMail(){
	   
	   var mail = document.getElementById("mail").value;
	   
		    $.ajax({
    method:"POST",
    url: "getUmail.php", 
    data: "mail="+mail,
    success: function(data){
		if(data == "Correct mail")
		{
			document.getElementById("err").innerHTML = "<p style='color:green'><small>Correct Email!!</small></p>";
		}
		else
		{
			document.getElementById("err").innerHTML = "<p style='color:red'><small>*Choose another Email</small></p>";
			
		}
     
    }
   });
	   
   
   
   }
   
   function getStudentId(){
	   $.ajax({
    method:"POST",
    url: "getStudentID.php", 
    success: function(data){
		 $("#studId").val(data);
     
    }
   });
	   
	   
   }
</script>
<script type="text/javascript">


	jQuery(document).ready(function($) {
		$(".scroll").click(function(event){		
			event.preventDefault();
			$('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
			
			
		});
		
		
		
	});
</script>



</head>
	
<body>


<!-- header -->
	<?php include("menu.php");?>
	</br></br>
<!-- //header -->

<!-- events -->
	<div class="events">
		<div class="container">
			<h3><span>Registration of Students</span></h3>
			<div class="events-grids">
				<div class="row">
				<!--- Student registration-->
				 <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" onsubmit="return false;" method="POST" id="studfrm" >
				  
					 
					 <div class="form-group row">
						 <div id="err"></div>
						  <label for="mail" class="col-sm-2 col-form-label">Email</label>
						  <div class="col-sm-9">
						   <input type="text" class="form-control" id="mail" onchange="getUMail();" name="mail" placeholder="Umail" >
						  </div>
						</div>
						 <div class="form-group row">
						  <label for="studId" class="col-sm-2 col-form-label">Student ID</label>
						  <div class="col-sm-9">
						   <input type="text" class="form-control" id="studId" name="studId" readonly="true" >
						   
						 </div>
						 <a href="#"><button type="button" name="SIDgenerate" class="btn btn-success" onclick="getStudentId();" id="SIDgenerate">Generate</button></a>
						</div>
						<div class="form-group row">
					 <input type="hidden" readonly="true"  name="appid" id="appid" value = <?php echo $id; ?>  class="form-control"/>
					 </div>
						</br></br>
						<div class="btn-group" style="float:right;">
						<button type="submit"  id="submit" onclick="registerStud();" class="btn btn-info">Submit</button>
						<button type="reset" class="btn btn-danger">Cancel</button>
						</div> 
				 </form>
         
          <br/>				
				
				</div>
			  <div class="clearfix"> </div>
			</div>
		</div>
	</div>
	<!-- //events -->
<!-- footer -->
	<?php include("footer.php");?>

<!-- //footer -->

  
<!-- for bootstrap working -->
	<script src="js/bootstrap.js"></script>
<!-- //for bootstrap working -->
<!-- here stars scrolling icon -->
	<script type="text/javascript">
	
		$(document).ready(function() {
							
			$().UItoTop({ easingType: 'easeOutQuart' });
			
				
	
		});
			
	</script>
				
</body>
</html>

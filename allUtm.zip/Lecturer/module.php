<?php
include("session_lecturer.php");
?>

<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE html>
<html>
<head>
<title>Lecturer Portal</title>
<link href="http://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css" rel="stylesheet">   
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
<link rel="stylesheet" href="http://cdn.datatables.net/1.10.2/css/jquery.dataTables.min.css"></style>
<script type="text/javascript" src="http://cdn.datatables.net/1.10.2/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="http://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
<?php include("head.php");?>
<script type="text/javascript">
	jQuery(document).ready(function($) {
		$(".scroll").click(function(event){		
			event.preventDefault();
			$('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
		});
		
		$("#lectures").hide();
        $("#assignment").hide(); 		
		$(document).on('click', '.btn_modules', function()
		{
			$("#intro").hide(); 
			$("#lectures").show();
			$("#assignment").show(); 
	   });
	});
</script>
<!-- start-smoth-scrolling -->

</head>
	
<body>
<!-- header -->
	<?php include("menu.php");?>
	</br></br>
<!-- //header -->
</br></br></br>
<!-- events -->
	<div class="events">
		<div class="container"  >
			<h3><span>Lectures & Assignments </span></h3>
			<p class="autem">Upload Lecture notes and Download Student's Assignments</p>
			</br></br>
			<div  class="col-md-4">
			 <!--- For modules-->
			 <button type="button" class="btn btn-secondary btn-lg btn-block" style="font-size:15px" id="Calendar">Calendar
			    <div></div>
			 </button>
			<?php
			 $query = "SELECT t.Cohort_ID,t.Tutor_ID,t.Status,t.M_code,m.M_name FROM tbltimetable as t,tblmodule as m WHERE t.Tutor_ID = '".$_SESSION["id"]."' AND t.M_code = m.M_code AND t.Status = 'active' AND t.Cohort_ID = '".$_GET["cohort"]."'";
			 $result = mysqli_query($mysqli,$query);
			 $num_results = mysqli_num_rows($result);
										
			  for($i=0; $i<$num_results; $i++) 
			   {
				$row = mysqli_fetch_assoc($result);
			?>
				<button type="button" class="btn btn-secondary btn-lg btn-block btn_modules"  style="font-size:15px" id="<?php  echo $row["M_code"]; ?>">
			<?php
				   echo $row["M_name"];
				}
			 ?>
			 
			 </button>
			
			</div>
            <div style="background-color:yellow;" class="col-md-8">
				<!--- For lecture materials and assignments-->
				<div id="intro">
				<p align="center"><i><u>Welcome to your E-teaching portal</u></i></p>
				<p>- Click on view calender to see your Event Calendar.</p>
				<p>- Click on a module to upload,view,delete and hide your lecture materials or download assignment for this module.</p>
				</div>
				
				<!---Lectures-->
				<div id="lectures">
				<ul class="nav nav-tabs">
				  <li role="presentation" class="active"><a href="#lectures">Lectures</a></li>
				  <li role="presentation"><a href="#assignment">Assignments</a></li>
				</ul>
					<p><u><a href="#" data-toggle="modal" data-target="#myModal">Click to upload teaching materials</a></u></p>
					<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
					  <div class="modal-dialog modal-lg">
						<div class="modal-content">
						  <div class="modal-header">
							<button type="button" class="close" data-dismiss="modal" aria-label="Close">
							  <span aria-hidden="true">&times;</span>
							</button>
							<h4 class="modal-title" id="myModalLabel">Uploading of Files</h4>
						  </div>
						  <!-- End of header -->
						  <div class="modal-body">
							
						  </div>
						  <!-- End of body -->
						  <div class="modal-footer">
							<button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
							<button type="button" class="btn btn-primary">Save changes</button>
						  </div>
						  <!-- End of footer -->
						</div>
					  </div>
					</div>
				</div>
				<!---Assignments-->
				<div id="assignment">
				
				</div>
			</div>			
			
			
			
			
			
		
				
	
	
	</div>
	</br></br></br>
<!-- //events -->
<!-- footer -->
<?php include("footer.php");?>
<!-- //footer -->
<!-- for bootstrap working -->
	<script src="js/bootstrap.js"></script>
<!-- //for bootstrap working -->


	<script type="text/javascript">
		$(document).ready(function() {
							
			$().UItoTop({ easingType: 'easeOutQuart' });
								
			});
			
			
		
	</script>

</body>
<script type="text/javascript">
$(document).ready(function(){
    $('#shrtTable').dataTable();
	$('#exportTable').dataTable();
});
</script>
</html>
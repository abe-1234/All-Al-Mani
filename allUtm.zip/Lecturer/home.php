<?php
include("session_lecturer.php");
?>

<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE html>
<html>
<head>
<title>Lecturer Portal</title>
<link href="http://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css" rel="stylesheet">   
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
<link rel="stylesheet" href="http://cdn.datatables.net/1.10.2/css/jquery.dataTables.min.css"></style>
<script type="text/javascript" src="http://cdn.datatables.net/1.10.2/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="http://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
<?php include("head.php");?>
<script type="text/javascript">
	jQuery(document).ready(function($) {
		$(".scroll").click(function(event){		
			event.preventDefault();
			$('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
		});
		$("#demo1").hide();
		$("#demo").hide();
		
		$("#viewTbl").click(function(){
          $("#demo1").toggle();
        });
		
		// $("#shrtview").click(function(){
          // $("#demo").toggle();
        // });
	});
</script>
<!-- start-smoth-scrolling -->

</head>
	
<body>
<!-- header -->
	<?php include("menu.php");?>
	</br></br>
<!-- //header -->

<!-- events -->
	<div class="events">
		<div class="container">
			<h3><span>News & Events</span></h3>
			<p class="autem">All Important tutors' News and Events about UTM</p>
			<div class="events-grids">
				
				<p><a href="#" id="viewTbl"><u>Click to view timetable</u></a></p>
				 
					<div id="demo1">  
					

					<button class="btn btn-primary" id="shrtview"  data-toggle="modal" data-target="#myModal">Full View</button>
					
					<div class="table-responsive">
					   <table id="shrtTable"  class="table table-bordered table-hover table-striped table-inverse">
						<thead class="bg-info">
							<tr >
								<td>Programme</td>
								<td>Cohort</td>
								<td>Module_Code</td>
								<td>Module_Title</td>
								<td>L+T/P</td>
								<td>FT/PT</td>
								<td>Day for Lecture</td>
								<td>Time for Lecture</td>
								<td>Time for Lecture</td>
								<td>Venue for Lecture</td>
								<td>Day for Practical</td>
								<td>Time for Practical</td>
								<td>Time for Practical</td>
								<td>Venue for Practical</td>
								
							</tr>
							<thead>
							<tbody >
							<?php
							$query = "SELECT prg.ProgrammeTitle,tbl.Status,tbl.Cohort_ID,tbl.M_code,module.M_name,tbl.LTP,tbl.mode,tbl.Tutor_ID,tbl.LDay,tbl.LTo,tbl.LFrom,tbl.LRoom,tbl.PDay,tbl.PTo,tbl.PFrom,tbl.PRoom FROM tbltimetable AS tbl INNER JOIN tblmodule AS module INNER JOIN tblcohort AS cohrt INNER JOIN tblprogramme AS prg ON tbl.Cohort_ID = cohrt.Cohort_ID AND tbl.M_code = module.M_code AND cohrt.ProgrammeID = prg.ProgrammeID WHERE tbl.Tutor_ID = '".$_SESSION["id"]."' AND tbl.Status = 'active'";
							$result = mysqli_query($mysqli,$query);
							$num_results = mysqli_num_rows($result);
							
							for($i=0; $i<$num_results; $i++) {
                             $row = mysqli_fetch_assoc($result);
							
								echo "<tr><td>".$row["ProgrammeTitle"]."</td><td>".$row["Cohort_ID"]."</td><td>".$row["M_code"]."</td><td>".$row["M_name"]."</td><td>".$row["LTP"]."</td><td>".$row["mode"]."</td><td>".$row["LDay"]."</td><td>".$row["LTo"]."</td><td>".$row["LFrom"]."</td><td>".$row["LRoom"]."</td><td>".$row["PDay"]."</td><td>".$row["PTo"]."</td><td>".$row["PFrom"]."</td><td>".$row["PRoom"]."</td></tr>";
							}
							
							
							
							?>
						</tbody>
					   </table>
			       </div>
				</div>

             <!-- full timetable view -->				
					</br></br></br>
					<div id="myModal" class="modal fade" role="dialog">
                      <div class="modal-dialog modal-lg">
					
					<div class="modal-content">
					  <div class="modal-header">
						<button type="button" class="close" data-dismiss="modal">&times;</button>
						<h4 class="modal-title">Full timetable</h4>
						

					  </div>
					
					
					<div class="modal-body">
					<div class="table-responsive">
					   <table id="exportTable"  class="table table-bordered table-hover table-striped table-inverse">
						<thead class="bg-info">
							<tr >
								<td>Programme</td>
								<td>Cohort</td>
								<td>No_of_Student</td>
								<td>Module_Code</td>
								<td>Head_of_Dept</td>
								<td>Programme_Director</td>
								<td>Programme_Coordinator</td>
								<td>Module_Title</td>
								<td>L+T/P</td>
								<td>FT/PT</td>
								<td>Surname</td>
								<td>Name</td>
								<td>Title</td>
								<td>Day_for_Lecture</td>
								<td>Time_for_Lecture</td>
								<td>Time_for_Lecture</td>
								<td>Venue_for_lecture</td>
								<td>Day_for_Practical</td>
								<td>Time_for_Practical</td>
								<td>Time_for_Practical</td>
								<td>Venue_for_Practical</td>
								<td>Remark</td>
							</tr>
							<thead>
							<tbody >
							<?php
							$query = "SELECT prg.ProgrammeTitle,tbl.Status,tbl.Cohort_ID,tbl.No_of_Stud,tbl.M_code,tbl.HeadDept,tbl.ProgDirect,tbl.ProgCoord,module.M_name,tbl.LTP,tbl.mode,tbl.Tutor_ID,tut.TLName,tut.TFName,tbl.Title,tbl.LDay,tbl.LTo,tbl.LFrom,tbl.LRoom,tbl.PDay,tbl.PTo,tbl.PFrom,tbl.PRoom,tbl.Remark FROM tbltimetable AS tbl INNER JOIN tbltutor AS tut INNER JOIN tblmodule AS module INNER JOIN tblcohort AS cohrt INNER JOIN tblprogramme AS prg ON tbl.Tutor_ID = tut.Tutor_ID AND tbl.Cohort_ID = cohrt.Cohort_ID AND tbl.M_code = module.M_code AND cohrt.ProgrammeID = prg.ProgrammeID WHERE tbl.Tutor_ID = '".$_SESSION["id"]."' AND tbl.Status = 'active'";
							$result = mysqli_query($mysqli,$query);
							$num_results = mysqli_num_rows($result);
							
							for($i=0; $i<$num_results; $i++) {
                             $row = mysqli_fetch_assoc($result);
							
								echo "<tr><td>".$row["ProgrammeTitle"]."</td><td>".$row["Cohort_ID"]."</td><td>".$row["No_of_Stud"]."</td><td>".$row["M_code"]."</td><td>".$row["HeadDept"]."</td><td>".$row["ProgDirect"]."</td><td>".$row["ProgCoord"]."</td><td>".$row["M_name"]."</td><td>".$row["LTP"]."</td><td>".$row["mode"]."</td><td>".$row["TLName"]."</td><td>".$row["TFName"]."</td><td>".$row["Title"]."</td><td>".$row["LDay"]."</td><td>".$row["LTo"]."</td><td>".$row["LFrom"]."</td><td>".$row["LRoom"]."</td><td>".$row["PDay"]."</td><td>".$row["PTo"]."</td><td>".$row["PFrom"]."</td><td>".$row["PRoom"]."</td><td>".$row["Remark"]."</td></tr>";
							}
							
							
							
							?>
						</tbody>
					   </table>
			       </div>
				 </div>
				  </div>
               
			</div>
		</div>
	</div>
	</div>
	</div>
	</br></br></br>
<!-- //events -->
<!-- footer -->
<?php include("footer.php");?>
<!-- //footer -->
<!-- for bootstrap working -->
	<script src="js/bootstrap.js"></script>
<!-- //for bootstrap working -->


	<script type="text/javascript">
		$(document).ready(function() {
							
			$().UItoTop({ easingType: 'easeOutQuart' });
								
			});
			
			
		
	</script>

</body>

</html>